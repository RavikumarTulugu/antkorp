$(function() {
	var createUUID = function() {
		return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
			var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
			return v.toString(16);
		});
	};
	var ws = new WebSocket("ws://bldsvrub:443");
	var clientid;
	ws.onopen = function() {
		console.log("Websocket Opened");

	}
	ws.onerror = function(e) {
		alert('ws Error Message:' + e.message);
	}
	ws.onclose = function() {
		//alert('ws closed');
	}
			ws.binaryType = 'arraybuffer';
	
	function wssend(obj) {
			console.log("request sent: ")
			console.log(obj);
			var service = obj.service;
			delete obj.service;
			delete obj.clientid;
			var jsonstring = JSON.stringify(obj);
			var sendBuffer = new ArrayBuffer(jsonstring.length + 4 + 12);
			var dv = new DataView(sendBuffer);
			//console.log("sendsvcmsg clientid: " + clientid);
			dv.setInt32(0, clientid);
			
			if (service.length < 12) {
				for (var i = 0; i < (12 - service.length); i++) {
					service += ' ';
				}
			}//fill space for missing chars
			for (var i = 0; i < service.length; i++) {
				dv.setUint8(i + 4, service.charCodeAt(i));
			}
			for (var i = 0; i < jsonstring.length; i++) {
				dv.setUint8(i + 16, jsonstring.charCodeAt(i));
			}
			ws.send(sendBuffer);
			return;
		}

		function recvSvcMessage(e) {
			var recvBuffer = e.data;
			console.log(e);
			var dv = new DataView(recvBuffer);
			clientid = dv.getInt32(0, false);
			//console.log("recvd clientid:" + clientid);
			var service = "";
			for (var i = 4; i < 16; i++) {
				service += String.fromCharCode(dv.getUint8(i));
			}
			var jsonstr = "";
			for (var i = 16; i < e.data.byteLength; i++) {
				jsonstr += String.fromCharCode(dv.getUint8(i));
			}
			//console.log(jsonstr);
			var obj = JSON.parse(jsonstr);
			obj.service=service.substring(0,service.indexOf(' '))||service;
			obj.clientid=clientid;
			return obj;
		}
	ws.onmessage = function(e) {
		
		var recvd = recvSvcMessage(e);//eval('(' + e.data + ')');
		clientid = recvd.clientid;
		console.log(["message recieved:",recvd]);
	}

	$('#getuserbtn').bind('click', function() {
		var gu = $('#unamegetuser').val();
		getuser(gu);
	});
	$('#adduserbtn').bind('click', function() {
		var gu = $('#unameadduser').val();
		adduser(gu);
	});
	$('#dltuserbtn').bind('click', function() {
		var gu = $('#unamedltuser').val();
		dltuser(gu);
	});
	$('#addgrpbtn').bind('click', function() {
		var gu = $('#addgrpname').val();
		addgroup(gu);
	});
	$('#getgrpbtn').bind('click', function() {
		var gu = $('#getgrpname').val();
		getgroup(gu);
	});
	$('#dltgrpbtn').bind('click', function() {
		var gu = $('#dltgrpname').val();
		dltgroup(gu);
	});

	function addgroup(grpname) {
		var unique = createUUID();
		var addgrp_obj = {
			clientid : clientid,
			service : "auth",
			request : "addgroup",
			cookie : unique,
			uid : 1000,
			gid : 0,
			gname : grpname
		}
		wssend(addgrp_obj);
	}

	

	function getgroup(grpname) {
		var unique = createUUID();
		var getgrp_obj = {
			clientid : clientid,
			service : "auth",
			request : "getgroup",
			cookie : unique,
			uid : 1000,
			gid : 0,
			gname : grpname
		};

		wssend(getgrp_obj);
	}

	function dltgroup(grpname) {
		var unique = createUUID();
		var remgrp_obj = {
			clientid : clientid,
			service : "auth",
			request : "remgroup",
			cookie : unique,
			uid : 1000,
			gid : 0,
			gname : grpname
		}
		wssend(remgrp_obj);
	}

	function getuser(userId) {

		var unique = createUUID();
		var getuser_obj = {
			clientid : clientid,
			service : "auth",
			request : "getuser",
			cookie : unique,
			uid : 0,
			gid : 1007,
			uname : userId,
			gname : 0
		}
	wssend(getuser_obj);

	}

	function adduser(userID) {

		var unique = createUUID();
		var adduser_obj = {
			clientid : clientid,
			service : "auth",
			request : "adduser",
			cookie : unique,
			uid : 0,
			gid : 1007,
			uname : userID,
			gname : 0
		}
		wssend(adduser_obj);

	}

	function dltuser(userID) {

		var unique = createUUID();
		var dltuser_obj = {
			clientid : clientid,
			service : "auth",
			request : "deluser",
			cookie : unique,
			uid : 0,
			gid : 1007,
			uname : userID,
			gname : 0
		}
		wssend(dltuser_obj);

	}
	
	
	
	/*
		 * Navigator Finding Offline or Online
		 */
		function updateOnlineStatus(msg) {
			var condition = navigator.onLine ? "ONLINE" : "OFFLINE";
			$('#state').addClass(condition);
		}


		$(document).bind("webkitvisibilitychange", handleVisibilityChange);
		document.body.addEventListener("offline", function() {
			updateOnlineStatus("offline")
		}, false);
		document.body.addEventListener("online", function() {
			updateOnlineStatus("online")
		}, false);

		/*
		 * PageVisibility API
		 */
		function handleVisibilityChange() {
			if (document.webkitHidden) {
				focus = false;

			} else {
				focus = true;

			}
		}
		/*
		 * Clock
		 *
		 setInterval(function() {
		 var currentTime = new Date();
		 var currentHours = currentTime.getHours();
		 var currentMinutes = currentTime.getMinutes();
		 var currentSeconds = currentTime.getSeconds();

		 // Pad the minutes and seconds with leading zeros, if required
		 currentMinutes = (currentMinutes < 10 ? "0" : "" ) + currentMinutes;
		 currentSeconds = (currentSeconds < 10 ? "0" : "" ) + currentSeconds;

		 // Choose either "AM" or "PM" as appropriate
		 var timeOfDay = (currentHours < 12 ) ? "AM" : "PM";

		 // Convert the hours component to 12-hour format if needed
		 currentHours = (currentHours > 12 ) ? currentHours - 12 : currentHours;

		 // Convert an hours component of "0" to "12"
		 currentHours = (currentHours == 0 ) ? 12 : currentHours;

		 // Compose the string for display
		 var currentTimeString = currentHours + ":" + currentMinutes + " " + timeOfDay;

		 $("#clock").html(currentTimeString);

		 }, 1000);
		 */
		
		
		
		/*
		 * OAuth Consumer Key:	 www.antkorp.in
OAuth Consumer Secret:	 H81lTGEdhjPYi642Bd121zFw



Request Token = 4/buTWq6R-XaVmy62tInmdSJzM_P0Y
Since you are using HMAC-SHA1, you also received a token secret:

Token Secret = loLt-bp8dbLWvEep6bKcVesO



Access Token = 1/ishiQaU1sghXD1S_PypYvgfUlfTD-ERnwvoro8tMAKI
		 */

});





/*
		 * List of Kinds of files
		 */
		var kinds = {
			unknown : "Unknown",
			directory : "Folder",
			symlink : "Alias",
			"symlink-broken" : "AliasBroken",
			"application/x-empty" : "TextPlain",
			"application/postscript" : "Postscript",
			"application/vnd.ms-office" : "MsOffice",
			"application/vnd.ms-word" : "MsWord",
			"application/vnd.ms-excel" : "MsExcel",
			"application/vnd.ms-powerpoint" : "MsPP",
			"application/pdf" : "PDF",
			"application/xml" : "XML",
			"application/vnd.oasis.opendocument.text" : "MsWord",
			"application/x-shockwave-flash" : "MsPP",
			"application/flash-video" : "VideoDV",
			"application/x-bittorrent" : "Torrent",
			"application/javascript" : "JS",
			"application/rtf" : "RTF",
			"application/rtfd" : "RTF",
			"application/x-font-ttf" : "TTF",
			"application/x-font-otf" : "TTF",
			"application/x-rpm" : "TextPlain",
			"application/x-web-config" : "TextPlain",
			"application/xhtml+xml" : "HTML",
			"application/docbook+xml" : "XML",
			"application/x-awk" : "XML",
			"application/x-gzip" : "ZIP",
			"application/x-bzip2" : "ZIP",
			"application/zip" : "ZIP",
			"application/x-zip" : "ZIP",
			"application/x-rar" : "RAR",
			"application/x-tar" : "TAR",
			"application/x-7z-compressed" : "ZIP",
			"application/x-jar" : "JAR",
			"text/plain" : "TextPlain",
			"text/x-php" : "PHP",
			"text/html" : "HTML",
			"text/javascript" : "JS",
			"text/css" : "CSS",
			"text/rtf" : "RTF",
			"text/rtfd" : "RTF",
			"text/x-c" : "C",
			"text/x-csrc" : "C",
			"text/x-chdr" : "CHeader",
			"text/x-c++" : "CPP",
			"text/x-c++src" : "CPP",
			"text/x-c++hdr" : "CPPHeader",
			"text/x-shellscript" : "Shell",
			"application/x-csh" : "Shell",
			"text/x-python" : "Python",
			"text/x-java" : "Java",
			"text/x-java-source" : "Java",
			"text/x-ruby" : "Ruby",
			"text/x-perl" : "Perl",
			"text/x-sql" : "Shell",
			"text/xml" : "XML",
			"text/x-comma-separated-values" : "CSV",
			"image/x-ms-bmp" : "BMP",
			"image/jpeg" : "JPEG",
			"image/gif" : "GIF",
			"image/png" : "PNG",
			"image/tiff" : "PNG",
			"image/x-targa" : "PNG",
			"image/vnd.adobe.photoshop" : "PNG",
			"image/xbm" : "PNG",
			"image/pxm" : "PNG",
			"audio/mpeg" : "AudioMPEG",
			"audio/midi" : "AudioMPEG",
			"audio/ogg" : "AudioMPEG",
			"audio/mp4" : "AudioMPEG",
			"audio/x-m4a" : "AudioMPEG",
			"audio/wav" : "AudioMPEG",
			"audio/x-mp3-playlist" : "AudioMPEG",
			"video/x-dv" : "VideoDV",
			"video/mp4" : "VideoDV",
			"video/mpeg" : "VideoDV",
			"video/x-msvideo" : "VideoDV",
			"video/quicktime" : "VideoDV",
			"video/x-ms-wmv" : "VideoDV",
			"video/x-flv" : "VideoDV",
			"video/x-matroska" : "VideoDV",
			"video/ogg" : "VideoDV"
		}

#!/bin/bash

function expect_password {
    expect -c "\
    set timeout 90
    set env(TERM)
    spawn $1
    expect \"password:\"
    send \"nccw3yld\r\"
    expect eof
  "
}

expect_password "scp js/akorp.js raju@helen:/var/www/html/antkorp/test/js"

expect_password "scp js/app.js raju@helen:/var/www/html/antkorp/test/js"

expect_password "scp js/jQuery.vaultcmenu.js raju@helen:/var/www/html/antkorp/test/js"

expect_password "scp css/akorp.css raju@helen:/var/www/html/antkorp/test/css"

expect_password "scp css/akorp.theme1.css raju@helen:/var/www/html/antkorp/test/css"

expect_password "scp index.html raju@helen:/var/www/html/antkorp/test"

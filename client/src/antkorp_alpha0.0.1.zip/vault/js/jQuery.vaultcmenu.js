(function($) {
	$.fn.cnxtmenu = function(options) {
		var defaults = {
			'menuid' : ''
		}, opt = $.extend({}, defaults, options);

		var mid = opt.menuid, file, list, fielPasteInOrOut;
		this.live({
			"contextmenu" : function(e) {

				e.preventDefault();
				e.stopPropagation();

				file = $(this);
				if ($(this).hasClass('file-div') || $(this).hasClass('filediv')) {

					filePasteInOrOut = true;
					e.ctrlKey ? $(this).addClass('selected') : ($(this).hasClass('selected')) ? '' : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');
					list = $(this).parent().children('.selected');
					$(mid).children().hide();
					$.each(opt.items, function(i, v) {
						$(mid).children('#' + i).show().unbind('click').bind('click', {
							current : this,
							file : file,
							list : list,
							pasteSpl : filePasteInOrOut
						}, v);
					})
					//$(mid).children().show().end().children('#create_file,#create_folder').hide();
					file.data('dir') ? $(mid).children('.fldremove').hide() : $(mid).children('#paste,#open,#newwnd').hide();

				} else if ($(this).hasClass('dstore-file-div')) {
					filePasteInOrOut = false;
					e.ctrlKey ? $(this).addClass('selected') : ($(this).hasClass('selected')) ? '' : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');
					list = $(this).parent().children('.selected');
					//$(mid).children().show().end().children('#create_file,#create_folder,#cut,#copy,#paste').hide();
					$(mid).children().hide();
					$.each(opt.items, function(i, v) {
						$(mid).children('#' + i).show().unbind('click').bind('click', {
							current : this,
							file : file,
							list : list,
							pasteSpl : filePasteInOrOut
						}, v);
					})
					file.data('dir') ? $(mid).children('.fldremove').hide() : $(mid).children('#paste,#open,#newwnd').hide();

				} else if ($(this).hasClass('file-list')) {

					//$(mid).children().hide().end().children('#paste,#create_file,#create_folder').show();
					filePasteInOrOut = false;
					$(mid).children().hide();
					$.each(opt.items, function(i, v) {
						$(mid).children('#' + i).show().unbind('click').bind('click', {
							current : this,
							file : file,
							list : list,
							pasteSpl : filePasteInOrOut
						}, v);
					})
				} else if ($(this).hasClass('dstore_file-list')) {
					filePasteInOrOut = false;
					$(mid).children().hide();
					$.each(opt.items, function(i, v) {
						$(mid).children('#' + i).show().unbind('click').bind('click', {
							current : this,
							file : file,
							list : list,
							pasteSpl : filePasteInOrOut
						}, v);
					})
				}

				$(mid).css({
					top : e.pageY + 'px',
					left : e.pageX + 'px'
				}).show();
				return false;
			}
		});

		$(mid).click(function() {
			$(mid).hide();
		});
		$(document).click(function() {
			$(mid).hide();
		});

		//return this;

	}
})(jQuery);

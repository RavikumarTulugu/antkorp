$(function() {

	//ws = new WebSocket("ws://bldsvrub:9980");

	var hasChanged = true;

	$(window).bind("beforeunload", function(event) {
		if (hasChanged)
			return "Your session is closing. Do you want to proceed?";
	});

	//$("<div/>").addClass("tgp-top-border akorp-ui").appendTo('body');
	//$("<div/>").addClass("tgp-right-border ").appendTo('body');
	//$("<div/>").addClass("theme-switcher akorp-ui").attr('title', "Switch Theme").appendTo('body');//.bind('click', handleThemeChange);
	
	
	
	
	

	var theme = true;
	function handleThemeChange() {
		if (theme) {
			$('<link />').attr({
				'rel' : 'stylesheet',
				'href' : 'css/akorp.theme1.css'
			}).appendTo('head');
			theme = false;
			$(this).css({
				'background-image' : "url(css/images/Blue_theme.png)",
				'color' : '#fbfbfb',
				'border-color' : '#00abf2'
			})

		} else {
			$('link[href="css/akorp.theme1.css"]').remove();
			theme = true;
			$(this).css({
				'background-image' : "url(css/images/light_theme.png)",
				'color' : '#00ADF3',
				'border-color' : '#f7f7f7'
			})
		}
	}


	

	//$('.content').children().hide().end().children('#kons').show();
	

	/*
	 * sample Planner code
	 */
	//$('#calender').datepicker();

});

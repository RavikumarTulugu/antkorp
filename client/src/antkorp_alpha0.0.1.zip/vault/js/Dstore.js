$(function() {
	//alert(new Date().getTime());
	$.browser.chrome = /chrome/.test(navigator.userAgent.toLowerCase());
	var tot_elems = [];
	if ($.browser.chrome) {
		var maptable = {};
		var akorp = {
			wsopen : function() {
				$('span#home').parent('li').addClass('node_active');
				//alert(localStorage.getItem('clipboard'));
				//akorp.indexedDB.open();
				updateOnlineStatus("load");
			},
			wsmessage : function(e) {

				var svr_cmds = eval('(' + e.data + ')');
				//console.log(maptable[svr_cmds.cookie]);
				if (init == 0) {
					clientid = svr_cmds.clientid;
					dir_json = {
						clientid : clientid,
						mesgtype : "request",
						service : "dstore",
						request : "getdir",
						cookie : guid,
						dname : '/tmp'

					}
					refresh();
					//ws.send(JSON.stringify(dir_json));
					maptable[dir_json.cookie] = 'tree';
					init++;
				} else if (svr_cmds.mesgtype == 'ack') {
					Uworker.port.postMessage(svr_cmds);
				} else {

					switch(maptable[svr_cmds.cookie]) {
						case 'download':
							var strdata = svr_cmds.data;
							svr_cmds.data = window.atob(strdata);
							Dworker.port.postMessage({
								obj : svr_cmds
							});
							break;
						case 'tree':
							form_tree(svr_cmds.direlements, expander);
							break;
						case 'getdirinfo':

							var store_data = [];
							// Enumerate the entire object store.
							var db = akorp.indexedDB.db;
							var trans = db.transaction(["tree"], IDBTransaction.READ_ONLY);
							var store = trans.objectStore("tree");

							// Get everything in the store;
							var keyRange = IDBKeyRange.lowerBound(0);
							var cursorRequest = store.openCursor();
							trans.oncomplete = function(evt) {
								console.log(store_data.length);
							};
							cursorRequest.onsuccess = function(e) {
								var result = e.target.result;
								if (!!result == false)
									return;
								store_data.push({
									"key" : result.key,
									"Treenode" : result.value.text
								});
								result.
								continue();
							};
							console.log(store_data);
							/*var idb_obj = akorp.indexedDB.getAllNodes(dir_json.dname);
							 if (svr_cmds.lastaccess == idb_obj.timestamp) {
							 var elements = akorp.indexedDB.getAllNodes();
							 form_tree(elements, expander);
							 } else {
							 //remove path object store
							 //call get request
							 }*/

							break;
						case 'question':

							if (!svr_cmds.status) {
								var button = $('<input type="checkbox" id="check" /><label for="check">Apply this answer for all</label>');
								$('#check').button();
								//console.log(button);
								var q_obj = {
									clientid : clientid,
									mesgtype : "answer",
									service : "dstore",
									cookie : svr_cmds.cookie,
									//answer://yes/no/yesall/noall
								};

								$('<div/>').append('<p>' + svr_cmds.estring + '</p><br/>').append(button).dialog({
									resizable : false,
									height : 'auto',
									modal : true,
									position : ['right', "bottom"],
									closeOnEscape : false,
									open : function(event, ui) {
										$(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
									},
									buttons : {
										"Yes" : function() {

											if (!$('#check').is(':checked'))
												q_obj.answer = 'yes';
											else
												q_obj.answer = 'yesall'

											ws.send(JSON.stringify(q_obj));
											maptable[q_obj.cookie] = 'question';
											$(this).dialog("close");
										},
										'No' : function() {

											if (!$('#check').is(':checked'))
												q_obj.answer = 'no';
											else
												q_obj.answer = 'noall'

											ws.send(JSON.stringify(q_obj));
											maptable[q_obj.cookie] = 'question';

											$(this).dialog("close");

										}
									}
								});
							} else {

								refresh();
								FODialog.dialog('close');
								console.log(svr_cmds.status);
							}
							break;
						case 'remove':
							break;
					}

				}

			},

			wserror : function(e) {
				alert('ws Error Message:' + e.message);
			},

			wsclose : function() {
				alert('ws closed');
			},
			werror : function(e) {
				consloe.log('ERROR: Line ', e.lineno, ' in ', e.filename, ': ', e.message);
			},
			dwmessage : function(e) {
				var down_data = e.data;
				if (!down_data.file) {
					console.log(down_data);
				} else if (down_data.file.mesgtype == 'ack' || down_data.file.mesgtype == 'request' || down_data.file.mesgtype == 'cancel') {
					ws.send(JSON.stringify(down_data.file));
					maptable[down_data.file.cookie] = 'download';
					dpr.setProgress(down_data.percent)
				} else if (down_data.file.mesgtype == 'save') {
					dpr.setProgress(down_data.percent)
					var dfname = down_data.file.dfname.substring(down_data.file.dfname.lastIndexOf('/') + 1, down_data.file.dfname.length);
					//var bb = new WebKitBlobBuilder;
					//bb.append(down_data.file.blob);
					//window.saveAs(down_data.file.blob, dfname);
					saveAs(down_data.file.fl, dfname);
					$('#dloads').find('div:eq(0)').remove();
					if ($('#dloads div').length == 0) {
						$('#downloads').jqxWindow('hide');
					}
				}
			},
			uwmessage : function(e) {
				var dat = e.data.obj;
				//console.log(dat);
				if (!e.data.obj) {
					console.log(e.data);
				} else if (dat.mesgtype == 'request' || dat.mesgtype == 'cancel') {
					var pcnt = e.data.prct;
					//console.log(Math.round(pcnt));
					//$('#upload_status').find('div[data-path="' + dat.fname + '"]').find('progress').val(Math.round(pcnt) / 100);
					upr.setProgress(Math.round(pcnt) / 100);
					/*if (Math.round(pcnt) == 100) {
					//$('#upload_status').find('div[data-path="' + dat.fname + '"]').remove();
					$('#upload_status').find('div:eq(0)').remove();
					if ($('#upload_status div').length == 0)
					$('#uploadwindow').jqxWindow('hide');
					}*/
					//console.log(JSON.stringify(dat));
					ws.send(JSON.stringify(dat));
					maptable[dat.cookie] = 'upload';
				} else if (dat.mesgtype == 'complete') {
					$('#upload_status').find('div:eq(0)').remove();
					if ($('#upload_status div').length == 0)
						$('#uploadwindow').jqxWindow('hide');
				}
			}
		};
		/*
		 *
		 */
		$("#refresh").button({
			icons : {
				primary : "ui-icon-refresh"
			},
			text : false,

		}).click(refresh);
		$("#gettree").button({
			icons : {
				primary : "ui-get-tree"
			},
			text : false,

		});
		$("#add_fl").button({
			icons : {
				primary : "ui-file-new"
			},
			text : false,

		});
		$("#add_fldr").button({
			icons : {
				primary : "ui-folder-new"
			},
			text : false,

		});
		$("#upload_fl").button({
			icons : {
				primary : "ui-icon-document"
			},
			text : false,

		});
		$("#upload_fldr").button({
			icons : {
				primary : "ui-icon-folder-collapsed"
			},
			text : false,

		});
		$("#home_folder").button({
			icons : {
				primary : "ui-icon-home"
			},
			text : false,

		}).click(function() {
			$('#home').click();
		});
		$("#parent").button({
			icons : {
				primary : "ui-icon-arrowthick-1-n"
			},
			text : false,

		}).click(parent);
		function parent() {
			var parent = dir_json.dname.substring(0, dir_json.dname.lastIndexOf('/'));
			if (parent != '')
				$('#nodes').find('span[data-path="' + parent + '"]').click();
			//console.log($('#nodes').jqxTree('selectedItem'));
		}

		// $('#upload_fl').button();
		// $('#upload_fldr').button();

		//$('.bset').buttonset();
		//$('.rbset').buttonset();

		var port=prompt("Please enter Port number","9980");
		var ws = new WebSocket("ws://bldsvrub:"+port);
		//ws.binaryType = 'arraybuffer';
		ws.onopen = akorp.wsopen;
		ws.onmessage = akorp.wsmessage;
		ws.onerror = akorp.wserror;
		ws.onclose = akorp.wsclose;

		var Dworker = new SharedWorker('Dstore_downloader.js');
		Dworker.port.start();
		Dworker.port.onerror = akorp.werror;
		Dworker.port.onmessage = akorp.dwmessage;

		var Uworker = new SharedWorker('Dstore_uploader.js');
		Uworker.port.start();
		Uworker.port.onerror = akorp.werror;
		Uworker.port.onmessage = akorp.uwmessage;

		var createUUID = function() {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		};

		var guid = createUUID(), init = 0, clientid, dir_json, fscreen = true;
		function enterFullscreen() {
			if (fscreen) {
				var el = document.querySelector("body");
				el.webkitRequestFullScreen();
				fscreen = false;
			} else {
				e.preventDefault();
				document.webkitCancelFullScreen();
				fscreen = true;
			}
		}

		function fullscreenhandle(e) {
			if (e.keyCode == 13) {

				// enter. ESC doesn't work for some reason. Need requestFullScreenWithKeys?
				e.preventDefault();
				document.webkitCancelFullScreen();
				fscreen = true;
			} else if (e.shiftKey && e.keyCode == 70 && e.altKey) {
				// alt+shift+f
				enterFullscreen();
				fscreen = false;

			}
		}


		akorp.indexedDB = {};
		var indexedDB = window.indexedDB || window.webkitIndexedDB || window.mozIndexedDB || window.msIndexedDB;
		// Handle the prefix of Chrome to IDBTransaction/IDBKeyRange.
		if ('webkitIndexedDB' in window) {
			window.IDBTransaction = window.webkitIDBTransaction;
			window.IDBKeyRange = window.webkitIDBKeyRange;
		}
		akorp.indexedDB.db = null;
		akorp.indexedDB.onerror = function(e) {
			console.log(e);
		};

		akorp.indexedDB.open = function() {
			var request = indexedDB.open("tree");
			request.onsuccess = function(e) {
				akorp.indexedDB.db = e.target.result;
				var db = akorp.indexedDB.db;
				var ver = "akorp_1.0"
				if (ver != db.version)
					var setvReq = db.setVersion(ver);
				setvReq.onsuccess = function(e) {
					db.createObjectStore('tree_nodes', {
						keyPath : "path"
					});
				}
				setvReq.onfailure = akorp.indexedDB.onerror;
			};
			request.onfailure = akorp.indexedDB.onerror;
		};

		akorp.indexedDB.dircheck = function(path) {

			var db = akorp.indexedDB.db;
			var trans = db.transaction('tree_nodes', 'readwrite');
			var store = trans.objectStore('tree_nodes');

			/*request.onsuccess = function(e) {
			 akorp.indexedDB.db = e.target.result;
			 if (akorp.indexedDB.db.objectStoreNames.contains(path)) {
			 dir_json.request = 'getdirinfo';
			 } else {

			 dir_json.request = 'getdir';
			 }
			 };
			 request.onfailure = akorp.indexedDB.onerror;*/
			var result = store.get(path);
			console.log(result);
			dir_json.request = 'getdir';
		}

		akorp.indexedDB.onerror = function(e) {
			console.log(e)
		};

		akorp.indexedDB.addNodes = function(path, msg) {

			var db = akorp.indexedDB.db;
			if (db.objectStoreNames.contains(path)) {
				db.deleteObjectStore(path);
			}
			db.createObjectStore(path, {
				keyPath : "timeStamp"
			});
			var trans = db.transaction([path], IDBTransaction.READ_WRITE);
			var store = trans.objectStore(path);

			var keyRange = IDBKeyRange.lowerBound(0);
			var cursorRequest = store.openCursor(keyRange);

			cursorRequest.onsuccess = function(e) {
				var result = e.target.result;
				if (!!result == false)
					return;

				node_data = result.value;
				result.
				continue();
			};
			cursorRequest.onerror = akorp.indexedDB.onerror;

			for (var g = 0; g < msg.length; g++) {
				var data = {
					"text" : msg[g], // todoText should be visible here
					"timeStamp" : new Date().getTime()
				};
				var request = store.put(data);
				request.onsuccess = function(e) {
					console.log('item added', e);
				};
				request.onerror = function(e) {
					console.log("Error Adding: ", e);
				};
			}
		};

		akorp.indexedDB.getAllNodes = function(path) {
			var store_data = [];
			// Enumerate the entire object store.
			var db = akorp.indexedDB.db;
			var trans = db.transaction(["tree"], IDBTransaction.READ_ONLY);
			var store = trans.objectStore("tree");

			// Get everything in the store;
			var keyRange = IDBKeyRange.lowerBound(0);
			var cursorRequest = store.openCursor();
			trans.oncomplete = function(evt) {
				console.log(store_data.length);
			};
			cursorRequest.onsuccess = function(e) {
				var result = e.target.result;
				if (!!result == false)
					return;
				store_data.push({
					"key" : result.key,
					"Treenode" : result.value.text
				});
				result.
				continue();
			};
		};

		/*
		 * PageVisibility API
		 */
		var focus = true;
		function handleVisibilityChange() {
			if (document.webkitHidden) {
				focus = false;

			} else {
				focus = true;

			}
		}

		/*
		 * Navigator Finding Offline or Online
		 */
		function updateOnlineStatus(msg) {
			var condition = navigator.onLine ? "ONLINE" : "OFFLINE";
			$('#state').addClass(condition);
		}

		function createNotificationInstance(options) {
			if (options.notificationType == 'simple') {
				return window.webkitNotifications.createNotification('icon.png', 'Notification Title', 'Notification content...');
			} else if (options.notificationType == 'html') {
				return window.webkitNotifications.createHTMLNotification(options.data);
			}
		}


		$('<a/>').attr('id', 'dclick').appendTo('body');
		function download(url) {
			var dfname = url.substring(url.lastIndexOf('/') + 1, url.length);
			var ur = url;
			$('#dclick').attr({
				'href' : ur,
				download : dfname,
			}).click();
			console.log(url);
		}

		function handleFileWriter(e, list) {

			$.each(list, function(i, v) {
				console.log(v);
				var fname = $(v).data('path');
				var size = $(v).data('fsize');
				var dfname = fname.substring(fname.lastIndexOf('/') + 1, fname.length);
				if (!$(v).data('dir')) {

					$('#downloads').jqxWindow('show');
					$('#downloads').jqxWindow('bringToFront');
					var guid = createUUID();

					var write_obj = {//json format
						clientid : clientid,
						mesgtype : "request",
						service : "dstore",
						request : "read",
						cookie : guid,
						fname : fname,
						size : 1024,
					};
					Dworker.port.postMessage({
						obj : write_obj,
						siz : size
					});
					$('#dloads').append('<div class="download_file">' + dfname + '<span class="cancel dc" data-fname="' + fname + '" data-cookie>Cancel</span></div>');
				} else {
					var data = "<strong>Directory is not supported!</strong><br><b>" + dfname + "</b> cannot be download.";

					$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>' + data + '</p>').dialog({
						resizable : false,
						height : 140,
						position : ['right', "bottom"],
						//modal : true,
						buttons : {
							OK : function() {
								$(this).dialog("close");
							}
						}
					});

				}
			});
		}


		$('.dc').live('click', function() {
			var fname = $(this).data('fname');

			$(this).parent().remove();
			if ($('#dloads div').length == 0)
				$('#downloads').jqxWindow('hide');

			var write_obj = {//json format
				clientid : clientid,
				mesgtype : "cancel",
				service : "dstore",
				request : "read",
				fname : fname,
			};
			Dworker.port.postMessage({
				obj : write_obj

			});

		});

		function sendreq(node_file_li) {
			tot_elems = [];
			var $this = node_file_li;
			$('#location').attr('value', 'antkorp:/' + $this.attr('data-path'));
			dir_json.cookie = createUUID();
			dir_json.dname = $this.attr('data-path');
			//akorp.indexedDB.dircheck(dir_json.dname)
			ws.send(JSON.stringify(dir_json));
			maptable[dir_json.cookie] = 'tree';
			$('#file-list').empty();
		}

		var expander, selectedClass = 'selected', lastClick, diffClick, clickDelay = 600;
		function form_tree(svr_msg, expndr) {
			var msg = svr_msg;
			//console.log(msg)
			var $trash = $('li.node_active');
			var $list = $("ul", $trash).length ? $("ul", $trash) : $("<ul/>").appendTo($trash);
			$list.hide();
			for (var i = 0; i < msg.length; i++) {
				if (msg[i].fname.indexOf('.') != 0) {
					if (msg[i].isdir == 'true' && !expndr) {
						var selectedItem = $('#nodes').jqxTree('selectedItem');
						if (selectedItem != null) {
							$('#nodes').jqxTree('expandItem', selectedItem.element);
							$('#nodes').jqxTree('addTo', {
								html : '<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dir_json.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span>'
							}, selectedItem.element);

						} else {
							var treeItems = $("#nodes").jqxTree('getItems');
							var firstItem = treeItems[0];
							var firstItemElement = firstItem.element;
							$('#nodes').jqxTree('addTo', {
								html : '<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dir_json.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span>'
							}, firstItemElement);
						}

						//$('<li><span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dir_json.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span></li>').appendTo($list).draggable({revert: true, containment: "#nodes"}).droppable({accept : 'div.4'});
					}

					filelist(msg[i].fname, msg[i].size, msg[i].isdir);

				}
			}

		}

		function initFileObject($li, dsbl) {
			$li.draggable({
				revertDuration : 10,
				revert : true, // grouped items animate separately, so leave this number low
				containment : '#dropzone',
				start : function(e, ui) {
					ui.helper.addClass(selectedClass);
				},
				stop : function(e, ui) {
					// reset group positions
					$('.' + selectedClass).css({
						top : 0,
						left : 0
					});
				},
				drag : function(e, ui) {
					// set selected group position to main dragged object
					// this works because the position is relative to the starting position
					$('.' + selectedClass).css({
						top : ui.position.top,
						left : ui.position.left
					});
				}
			}).droppable({
				'disable' : dsbl,
				accept : '.file-div',
				greedy : true,
				drop : function() {
					alert('hi this');
					$('.' + selectedClass).remove();
				}
			});
		}

		function filelist(fname, size, isdir) {
			var src = isdir == 'true' ? 'css/images/folder.png' : 'css/images/mimes/undefined.png';
			var dsbl = (isdir == 'true') ? false : true;
			//console.log(dsbl);
			var $item = $("<li></li>").attr({
				'data-fname' : fname,
				'data-path' : dir_json.dname + '/' + fname,
				'data-dir' : isdir,
				'data-fsize' : size
			}).addClass("file-div").append("<div class='fsdiv' ><img class='fselem' src='" + src + "' height=50px width=50px ><br/><span class='fname fselem' >" + fname + "</span></div>");
			initFileObject($item);
			$('#file-list').append($item, dsbl);
		}

		/* File upload process with drag and Drop, web worker and web socket
		 * TODO: it should check
		 */
		/*		function handleFileSelect(ev) {
		 $(this).children('ul').removeClass('droper');
		 $('#uploadwindow').jqxWindow('show');
		 ev.stopPropagation();
		 ev.preventDefault();
		 var files = ev.target.files || ev.dataTransfer.files;
		 // FileList object.
		 worker.port.postMessage({
		 'mesgtype' : 'file_list',
		 'files' : files,
		 'dname' : dir_json.dname,
		 clientid : clientid,
		 });
		 // files is a FileList of File objects. List some properties.
		 for (var i = 0, f; f = files[i]; i++) {
		 //alert(f.webkitRelativePath);

		 /*worker.port.postMessage({
		 'file' : f,
		 'dname' : dir_json.dname
		 });*
		 $('#uploadwindow').jqxWindow('bringToFront');
		 $('#upload_status').append('<div class="upload_file">' + f.name + '<span class="cancel uc" data-fname="' + f.name + '">Cancel</span></div>');
		 filelist(f.name, f.size, false);
		 }
		 }
		 */
		function handleFileSelect(ev) {
			ev.stopPropagation();
			ev.preventDefault();
			var length = ev.dataTransfer.items.length || ev.target.files.length;
			var src, isdir, septr, path_ext = [], q = 0;
			for (var i = 0, f; i < length; i++) {
				var entry = ev.dataTransfer.items[i].webkitGetAsEntry();

				if (entry.isFile) {
					isdir = 'false';
				} else {
					isdir = 'true';
				}
				filelist(entry.name, entry.size, isdir);
				traverseFileTree(entry)
			}
		}

		function traverseFileTree(item, path) {
			path = path || "/";
			if (item.name.indexOf('.') != 0) {
				if (item.isFile) {
					// Get file
					item.file(function(file) {
						//console.log("File:", path + file.name);
						Uworker.port.postMessage({
							'mesgtype' : 'file_list',
							'files' : file,
							'dname' : dir_json.dname + path + file.name,
							clientid : clientid,
						});
						$('#upload_status').append('<div class="upload_file">' + file.name + '<span class="cancel uc" data-fname="' + file.name + '">Cancel</span></div>');
					});
					$('#uploadwindow').jqxWindow('show');
					$('#uploadwindow').jqxWindow('bringToFront');
				} else if (item.isDirectory) {
					// Get folder contents

					var guid = createUUID();
					var add_obj = {
						clientid : clientid,
						mesgtype : "request",
						service : "dstore",
						request : 'create_dir',
						cookie : guid,
						source : dir_json.dname,
					}
					var spath = item.fullPath;
					var sep = spath.lastIndexOf('/');
					var source_ext = spath.substring(0, sep);
					add_obj.source = dir_json.dname + source_ext;
					add_obj.srcargs = [spath.substring(sep + 1, spath.length)];
					//console.log(JSON.stringify(add_obj));
					ws.send(JSON.stringify(add_obj));
					maptable[add_obj.cookie] = 'question';
					//console.log(item);
					var dirReader = item.createReader();
					dirReader.readEntries(function(entries) {
						for (var i = 0; i < entries.length; i++) {
							traverseFileTree(entries[i], path + item.name + "/");
						}
					});

				}
			}
		}


		$('.upload_file, .download_file').live('hover', function() {
			$(this).children().toggleClass('cancel');
		});

		$('.uc').live('click', function(e) {
			var fname = $(this).data('fname');
			//console.log(fname);
			$(this).parent().remove();
			if ($('#upload_status div').length == 0)
				$('#uploadwindow').jqxWindow('hide');

			Uworker.port.postMessage({
				'mesgtype' : 'cancel',
				'fname' : fname,
				'dname' : dir_json.dname,
				clientid : clientid,
			});
		});

		function handleDragOver(e) {
			e.stopPropagation();
			e.preventDefault();
			e.dataTransfer.dropEffect = 'copy';
			// Explicitly show this is a copy.
		}

		function refresh() {
			$('#nodes').find('span[data-path="' + dir_json.dname + '"]').click();
		}

		function info(e, fname, s, f) {
			var fname = f.data("path");
			var s = f.data('fsize');
			var dfname = fname.substring(fname.lastIndexOf('/') + 1, fname.length);
			var typeinfo = (fname.lastIndexOf('.') > 0) ? fname.substring(fname.lastIndexOf('.') + 1, fname.length) : 'unknown';
			var finfo = f.data('dir') ? 'Type : <b>Folder</b>' : 'Type :  <b>' + typeinfo + ' Document</b><br>Size :  <b>' + s + ' Bytes</b>';
			var data = '<img src="css/images/info.png" height=32 width=32 align=left />Name : <b>' + dfname + '</b><br>' + finfo;
			$('<div><div/><div/></div>').appendTo('body').jqxWindow({
				height : '120px',
				width : 300,
				resizable : false,
				draggable : false,
				title : 'Info',
				content : data,
				isModal : true,
				closeButtonAction : 'close'
			});
		}

		function openfn(e, file) {
			if (file.data('dir')) {
				$('#nodes').find('span[data-path="' + file.data('path') + '"]').click();
			}
		}

		function f_rename(e, item) {
			$(".rename").live('keypress', function(e) {
				if (e.which == 13) {
					$(this).removeClass('rename').attr('contenteditable', 'false');
				};
			});
			console.log(item);
			item.find('span').addClass('rename').attr('contenteditable', 'true').focus();
		}

		/*
		 * UI Code
		 */

		setInterval(function() {
			var currentTime = new Date();
			var currentHours = currentTime.getHours();
			var currentMinutes = currentTime.getMinutes();
			var currentSeconds = currentTime.getSeconds();

			// Pad the minutes and seconds with leading zeros, if required
			currentMinutes = (currentMinutes < 10 ? "0" : "" ) + currentMinutes;
			currentSeconds = (currentSeconds < 10 ? "0" : "" ) + currentSeconds;

			// Choose either "AM" or "PM" as appropriate
			var timeOfDay = (currentHours < 12 ) ? "AM" : "PM";

			// Convert the hours component to 12-hour format if needed
			currentHours = (currentHours > 12 ) ? currentHours - 12 : currentHours;

			// Convert an hours component of "0" to "12"
			currentHours = (currentHours == 0 ) ? 12 : currentHours;

			// Compose the string for display
			var currentTimeString = currentHours + ":" + currentMinutes + " " + timeOfDay;

			$("#clock").html(currentTimeString);

		}, 1000);

		$('.fullscreen').click(enterFullscreen);

		document.addEventListener('keydown', fullscreenhandle, false);

		$(document).bind("webkitvisibilitychange", handleVisibilityChange);
		document.body.addEventListener("offline", function() {
			updateOnlineStatus("offline")
		}, false);
		document.body.addEventListener("online", function() {
			updateOnlineStatus("online")
		}, false);

		$('span.dirnode').live('click', function() {
			$node_li = $(this)
			var selectedItem = $('#nodes').jqxTree('selectedItem');
			//console.log(selectedItem);
			$node_li.parent().next("ul").remove();
			//$node_li.parent().parents('ul').show();
			/*if ($node_li.hasClass("tree_expand")) {
			 expander = true;
			 $node_li.removeClass("tree_expand").next('ul').slideUp('slow');
			 } else {
			 expander = false;
			 $('li.node_active').removeClass('node_active');
			 $node_li.next('ul').remove().end().parent('li').addClass('node_active').end().addClass('tree_expand has_tree');
			 }*/
			sendreq($node_li);
		});
		jQuery.event.props.push('dataTransfer');
		//setting the property data transfer
		// Setup the dnd listeners.
		var dropZone = $('#dropzone');
		dropZone.bind('dragover', handleDragOver);
		dropZone.bind('drop', handleFileSelect);
		$('#inputmode').bind('change', handleFileSelect);
		/*
		 * Menubar Items functionality
		 */

		$('#add_fl').click(create_file);

		function create_file() {
			var guid = createUUID();
			var add_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "dstore",
				request : 'create_file', //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dir_json.dname,
				//destination:
				srcargs : 'arg'
			}

			//filelist('untitled', 0, false);
			$('<div/>').append("Enter The File Name:<input type='text' id='flname'>").dialog({
				resizable : false,
				title : 'Prompt',
				height : 140,
				modal : true,
				buttons : {
					"Ok" : function() {
						if ($('input#flname').val() != '') {
							add_obj.srcargs = [$('input#flname').val()];
							ws.send(JSON.stringify(add_obj));
							maptable[add_obj.cookie] = 'question';
							$(this).dialog("close").remove();
						}
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});

		}

		function create_folder() {
			var guid = createUUID();
			var add_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "dstore",
				request : 'create_dir', //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dir_json.dname,
				//destination:
				//srcargs : clipboard_obj.srcargs
			}
			$('<div/>').append("Enter The File Name:<input type='text' id='flname'>").dialog({
				resizable : false,
				title : 'Prompt',
				height : 140,
				modal : true,
				buttons : {
					"Ok" : function() {
						if ($('input#flname').val() != '') {
							add_obj.srcargs = [$('input#flname').val()];
							console.log(JSON.stringify(add_obj));
							ws.send(JSON.stringify(add_obj));
							maptable[add_obj.cookie] = 'question';
							$(this).dialog("close").remove();
						}
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});
		}


		$('#add_fldr').click(create_folder);

		$('#upload_fl').click(function() {
			$('#inputmode').removeAttr('webkitdirectory').attr('multiple', true).click();
		});
		$('#upload_fldr').click(function() {
			$('#inputmode').removeAttr('multiple').attr('webkitdirectory', true).click();
		});
		$('#nodes').fadeOut();

		$('#gettree').click(function() {
			$('#nodes').fadeToggle();

		});

		/*$('#file-list').sortable().cnxtmenu({
		 'menuid' : '#cmenu',
		 paste : paste,
		 create_file : create_file,
		 create_folder : create_folder
		 });*/

		$('#dropzone').cnxtmenu({
			'menuid' : '#cmenu',
			paste : paste,
			create_file : create_file,
			create_folder : create_folder
		})

		$('li.file-div').live('click', function(e) {
			//$('span.rename').removeClass('rename').attr('contenteditable', 'false');
			e.ctrlKey ? $(this).toggleClass('selected') : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');
			//$(this).addClass('selected');

			//e.ctrlKey ? $(this).addClass('selected') : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');

			var fname = $(this).data('fname');
			var typeinfo = (fname.lastIndexOf('.') > 0) ? fname.substring(fname.lastIndexOf('.') + 1, fname.length) : 'unknown';
			var size = $(this).data('fsize');
			var finfo = $(this).data('dir') ? 'Folder' : typeinfo + ' Document' + "&nbsp;&nbsp;&nbsp;" + size + ' Bytes';
			//status_note(fname + " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; " + finfo);
		}).live('dblclick', function() {
			var $file_li = $(this);
			if ($file_li.attr('data-dir') == 'true') {
				$('#nodes').find('span[data-path="' + $file_li.data("path") + '"]').click();
				//sendreq($file_li);
			} else {
				openfn();
			}
		}).cnxtmenu({
			'menuid' : '#cmenu',
			open : openfn,
			download : handleFileWriter,
			rename : f_rename,
			infoCallback : info,
			dlt : remove,
			copy : copy,
			cut : cut,
			paste : paste,

		});

		function copy(e, list) {
			var args = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
			});
			localStorage.clear();
			localStorage.setItem('clipboard', JSON.stringify({
				'request' : 'copy',
				'srcargs' : args,
				'source' : dir_json.dname
			}));
		}

		function cut(e, list) {
			var args = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
			});
			localStorage.clear();
			localStorage.setItem('clipboard', JSON.stringify({
				'request' : 'move',
				'srcargs' : args,
				'source' : dir_json.dname
			}));
		}

		var FODialog = $('<div id="circular3dG"><div id="circular3d_1G" class="circular3dG"></div><div id="circular3d_2G" class="circular3dG"></div><div id="circular3d_3G" class="circular3dG"></div><div id="circular3d_4G" class="circular3dG"></div><div id="circular3d_5G" class="circular3dG"></div><div id="circular3d_6G" class="circular3dG"></div><div id="circular3d_7G" class="circular3dG"></div><div id="circular3d_8G" class="circular3dG"></div></div>');

		function paste(e, list, dest) {
			var clipboard_obj = JSON.parse(localStorage.getItem('clipboard'));
			/*$.each(clipboard_obj.srcargs,function(v){
			 filelist(v, 4096, 'false');
			 })*/
			var destination = dest ? dest : dir_json.dname;
			var guid = createUUID();
			var paste_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "dstore",
				request : clipboard_obj.request, //move||copy||remove||create_file||create_dir
				cookie : guid,
				source : clipboard_obj.source,
				destination : destination,
				srcargs : clipboard_obj.srcargs
			}
			ws.send(JSON.stringify(paste_obj));
			maptable[paste_obj.cookie] = 'question';

			FODialog.dialog({
				resizable : false,
				title : 'File Operation',
				closeOnEscape : false,
				open : function(event, ui) {
					$(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
				},
				height : 140,
				modal : true,
			});

		}

		function remove(e, list) {
			var args = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
			});
			var guid = createUUID();
			var dlt_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "dstore",
				request : "remove", //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dir_json.dname,
				//destination:
				srcargs : args
			}

			$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>These items will be permanently deleted and cannot be recovered. Are you sure?</p>').dialog({
				resizable : false,
				height : 140,
				modal : true,
				buttons : {
					"Delete all items" : function() {
						$(this).dialog("close");
						ws.send(JSON.stringify(dlt_obj));
						maptable[dlt_obj.cookie] = 'remove';
						refresh();
					},
					Cancel : function() {
						$(this).dialog("close");
					}
				}
			});

			console.log(dir_json.dname);
		}


		$('body').bind({
			'unload' : function() {
				ws.close();
				Uworker.terminate();
				Dworker.terminate();
				localStorage.clear();
				window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
				var fs = null;

				window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function(filesystem) {
					fs = filesystem;
				}, errorHandler);

				var dirReader = fs.root.createReader();
				dirReader.readEntries(function(entries) {
					for (var i = 0, entry; entry = entries[i]; ++i) {
						if (entry.isDirectory) {
							entry.removeRecursively(function() {
							}, errorHandler);
						} else {
							entry.remove(function() {
							}, errorHandler);
						}
					}
				});

			}
		});
		$(document).bind({
			'contextmenu' : function() {
				return false;
			}
		})
		/*
		 * Jqwidegets Code
		 *
		 */
		$('.statusbar').slideUp();
		$('#sbar').hover(function(e) {
			$('.statusbar').stop().slideToggle('slow');
			//.css({display: 'block'})
		});
		$('#vault').dblclick(function() {
			$('#window').jqxWindow('show');
		})
		$('#vault').click(function() {
			$(this).addClass("icons");
		})

		$('#window').jqxWindow({
			height : 600,
			width : 900,
			minHeight : 600,
			maxHeight : 600,
			maxWidth : 1000,
			theme : 'darkblue',
			autoOpen : true,
			showCollapseButton : false,
			resizable : true
		});
		function whide(e, d) {
			if (d) {
				var data = $('#' + e.target.id).jqxWindow('title');
				$('.statusbar div:contains(' + data + ')').remove();
			}

		}

		/*$('#window').bind('collapse', function(event) {
		 dcd=false;
		 $(this).jqxWindow('hide');

		 });*/

		var dcd = true;
		$('#window').bind('hide', function(event) {
			whide(event, dcd);
			dcd = true;
		});

		$('#window').bind('show', function(e) {
			//console.log(this.id);
			var data = $('#' + this.id).jqxWindow('title');
			if ($('.statusbar div:contains(' + data + ')').length == 0) {
				var item = $('<div />').append(data).addClass('sbar-item').data('wid', this.id);
				$('.statusbar').append(item);
			}
		});

		$('.sbar-item').live('click', function() {
			var id = '#' + $(this).data('wid');
			if (!$(id).jqxWindow('isOpen')) {
				$(id).jqxWindow('show');
				$(id).jqxWindow('expand');
			} else {
				dcd = false;
				$(id).jqxWindow('hide');

			}
		})
		$('#uploadwindow').jqxWindow({
			autoOpen : false,
			showCloseButton : false,
			showCollapseButton : true,
			width : 'auto',
			height : 'auto'
		});
		$('#downloads').jqxWindow({
			autoOpen : false,
			showCloseButton : false,
			showCollapseButton : true,
			height : 300,
			width : 310
		});

		var theme = getTheme();
		$('#nodes').jqxTree({
			theme : theme
		});
		var upr = $("#uprogress").percentageLoader({
			width : 100,
			height : 100,
			progress : 0,
			position : {
				x : 200,
				y : 400
			},
			animationType : 'slide'
		});
		var dpr = $("#progress").percentageLoader({
			width : 100,
			height : 100,
			progress : 0,
			position : {
				x : 200,
				y : 400
			},
			animationType : 'slide'
		});

		/*
		 * List of Kinds of files
		 */
		var kinds = {
			unknown : "Unknown",
			directory : "Folder",
			symlink : "Alias",
			"symlink-broken" : "AliasBroken",
			"application/x-empty" : "TextPlain",
			"application/postscript" : "Postscript",
			"application/vnd.ms-office" : "MsOffice",
			"application/vnd.ms-word" : "MsWord",
			"application/vnd.ms-excel" : "MsExcel",
			"application/vnd.ms-powerpoint" : "MsPP",
			"application/pdf" : "PDF",
			"application/xml" : "XML",
			"application/vnd.oasis.opendocument.text" : "MsWord",
			"application/x-shockwave-flash" : "MsPP",
			"application/flash-video" : "VideoDV",
			"application/x-bittorrent" : "Torrent",
			"application/javascript" : "JS",
			"application/rtf" : "RTF",
			"application/rtfd" : "RTF",
			"application/x-font-ttf" : "TTF",
			"application/x-font-otf" : "TTF",
			"application/x-rpm" : "TextPlain",
			"application/x-web-config" : "TextPlain",
			"application/xhtml+xml" : "HTML",
			"application/docbook+xml" : "XML",
			"application/x-awk" : "XML",
			"application/x-gzip" : "ZIP",
			"application/x-bzip2" : "ZIP",
			"application/zip" : "ZIP",
			"application/x-zip" : "ZIP",
			"application/x-rar" : "RAR",
			"application/x-tar" : "TAR",
			"application/x-7z-compressed" : "ZIP",
			"application/x-jar" : "JAR",
			"text/plain" : "TextPlain",
			"text/x-php" : "PHP",
			"text/html" : "HTML",
			"text/javascript" : "JS",
			"text/css" : "CSS",
			"text/rtf" : "RTF",
			"text/rtfd" : "RTF",
			"text/x-c" : "C",
			"text/x-csrc" : "C",
			"text/x-chdr" : "CHeader",
			"text/x-c++" : "CPP",
			"text/x-c++src" : "CPP",
			"text/x-c++hdr" : "CPPHeader",
			"text/x-shellscript" : "Shell",
			"application/x-csh" : "Shell",
			"text/x-python" : "Python",
			"text/x-java" : "Java",
			"text/x-java-source" : "Java",
			"text/x-ruby" : "Ruby",
			"text/x-perl" : "Perl",
			"text/x-sql" : "Shell",
			"text/xml" : "XML",
			"text/x-comma-separated-values" : "CSV",
			"image/x-ms-bmp" : "BMP",
			"image/jpeg" : "JPEG",
			"image/gif" : "GIF",
			"image/png" : "PNG",
			"image/tiff" : "PNG",
			"image/x-targa" : "PNG",
			"image/vnd.adobe.photoshop" : "PNG",
			"image/xbm" : "PNG",
			"image/pxm" : "PNG",
			"audio/mpeg" : "AudioMPEG",
			"audio/midi" : "AudioMPEG",
			"audio/ogg" : "AudioMPEG",
			"audio/mp4" : "AudioMPEG",
			"audio/x-m4a" : "AudioMPEG",
			"audio/wav" : "AudioMPEG",
			"audio/x-mp3-playlist" : "AudioMPEG",
			"video/x-dv" : "VideoDV",
			"video/mp4" : "VideoDV",
			"video/mpeg" : "VideoDV",
			"video/x-msvideo" : "VideoDV",
			"video/quicktime" : "VideoDV",
			"video/x-ms-wmv" : "VideoDV",
			"video/x-flv" : "VideoDV",
			"video/x-matroska" : "VideoDV",
			"video/ogg" : "VideoDV"
		}

	} else {
		$('body').hide();
		alert("We only support Google Chrome");
	}
});

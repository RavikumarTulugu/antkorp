/*!
 * antkorp - Enterprise collaboration and communication Tool
 * Version 0.0  (2012-04-15)
 * http://www.antkorp.in
 *
 * Copyright@2012, www.antkorp.in
 * Commercially Licensed.
 */

$(function() {
	$.browser.chrome = /chrome/.test(navigator.userAgent.toLowerCase());
	$(".akorp-ui").hide();

	if ($.browser.chrome) {
		var maptable = {};
		var clientid;
		var loginuserid;
		var peerConnCreated = false;
		var peerConn = null;
		var cameraOn = false;
		var svcName = "";
		var myname = "";
		var hisname = "";
		var iceStarted = false;
		var iceComplete = false;
		var callPending = false;
		var answerPending = true;
		var hisSdp = null;
		var sourcevid = null;
		var remotevid = null;
		var services = {
			fmgr : true,
			dstore : true,
			kons : true,
			rtc : true,
			auth : true,
			ngw : true
		}

		var akorp = {
			werror : function(e) {
				consloe.log('ERROR: Line ', e.lineno, ' in ', e.filename, ': ', e.message);
			}
		}

		var createUUID = function() {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
				var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		};

		var guid = createUUID(), init = true, dir_json, fscreen = true;

		var expander, selectedClass = 'selected', lastClick, diffClick, clickDelay = 600;
		var copyOrCutElements = [];
		var theme = getTheme();

		/*
		############################################################################################################################################
		#                																														 ##
		#																Web Socket Stuff.                                                    <<<<
		#																																		 ##
		############################################################################################################################################
		*/

		//var port=prompt("Please enter Port number","9980");
		var ws = new WebSocket("ws://www.antkorp.in:443");
		ws.binaryType = 'arraybuffer';
		ws.onopen = function() {

			$('span#home').parent('li').addClass('node_active');

			noty({
				layout : 'bottomRight',
				theme : 'default',
				type : 'success',
				text : 'Welcome to antkorp!',
				timeout : 2000
			});

		}
		ws.onerror = function(e) {
			alert('ws Error Message:' + e.message);
		}
		ws.onclose = function() {
			console.log("Websocket connection closed");
			var noty1 = noty({
				layout : 'bottomRight',
				theme : 'default',
				type : 'error',
				text : 'Unable to connect to the server temporarily. Please try after some time!',
				timeout : 3000
			});

			$("body").hide();

			alert('Unable to connect to the server temporarily. Please try after some time!');

		}
		function wssend(obj) {
			//console.log("request sent: ")
			//console.log(obj);
			var service = obj.service;
			delete obj.service;
			delete obj.clientid;

			if (services[service]) {
				var jsonstring = JSON.stringify(obj);
				var sendBuffer = new ArrayBuffer(jsonstring.length + 4 + 12);
				var dv = new DataView(sendBuffer);

				dv.setInt32(0, clientid);

				if (service.length < 12) {
					for (var i = 0; i < (12 - service.length); i++) {
						service += ' ';
					}
				}//fill space for missing chars
				for (var i = 0; i < service.length; i++) {
					dv.setUint8(i + 4, service.charCodeAt(i));
				}
				for (var i = 0; i < jsonstring.length; i++) {
					dv.setUint8(i + 16, jsonstring.charCodeAt(i));
				}
				ws.send(sendBuffer);
				return;
			} else {
				noty({
					layout : 'bottomRight',
					theme : 'default',
					type : 'error',
					text : 'we are sorry, one of our services is down at this moment.',
					timeout : 5000
				});
			}
		}

		function recvSvcMessage(e) {
			var recvBuffer = e.data;
			var dv = new DataView(recvBuffer);
			clientid = dv.getInt32(0, false);

			var service = new String();
			for (var i = 4; i < 16; i++) {
				service += String.fromCharCode(dv.getUint8(i));
			}
			var jsonstr = "";
			for (var i = 16; i < e.data.byteLength; i++) {
				jsonstr += String.fromCharCode(dv.getUint8(i));
			}

			//console.log(jsonstr);
			//console.log(service);
			var obj = eval('(' + jsonstr.toString() + ')');
			//JSON.parse(jsonstr.toString());

			service = service.toString().replace(/[\x00-\x1F\x80-\xFF]/g, "");
			obj.service = service.substring(0, service.indexOf(' ')) || service;

			obj.clientid = clientid;
			return obj;
		}


		ws.onmessage = function(e) {

			/*
			 * Evaluate the arraybuffer using dataview with the function recvSvcMessage.
			 */
			var recvd = recvSvcMessage(e)//eval('(' + e.data + ')');
			//console.log("ws recieved: ");
			//console.log(recvd);

			if (init) {
				clientid = recvd.clientid;
				console.log(clientid);
				if (!loginsuccess) {
					//loginuser(fbusername);
				}
				//FIXME: desable on facebook login enabled.
				init = false;

			} else if (recvd.service) {

				var serv = $.trim(recvd.service);

				switch(serv) {
					case 'fmgr':
						handleFmgrMessage(recvd);
						break;
					/*case 'dstore':
					 handleDstoreMessage(recvd);
					 break;*/
					case 'kons':
						handleKonsMessage(recvd);
						break;
					case 'rtc':
						handleRtcMessage(recvd);
						break;
					case 'auth':
						handleAuthMessage(recvd);
						break;
					case 'ngw':
						handleServiceStatus(recvd);
						break;
					default:
						//if no service is specified then print it in console log.
						console.log("Service not recognised:");
						console.log(recvd);
				}
			}
		}
		function handleServiceStatus(resp) {

			var svcname;
			var svcstatus;

			if (resp.eventtype == "service_up") {
				svcstatus = true;
			} else {
				svcstatus = false;
			}

			if (resp.service_name == "fmgr") {
				svcname = "Vault";
			} else if (resp.service_name == "dstore") {
				svcname = "Dstore";
			} else if (resp.service_name == "kons") {
				svcname = "Konverations";
			} else if (resp.service_name == "rtc") {
				svcname = "Communication"
			} else if (resp.service_name == "auth") {
				svcname = "Authentication"
			}

			var stts = svcstatus ? "up" : "down";
			var stype = svcstatus ? "success" : "error";
			noty({
				layout : 'bottomRight',
				theme : 'default',
				type : stype,
				text : svcname + " service is " + stts,
				timeout : 5000
			});

			services[resp.service_name] = svcstatus;
		}

		/*
		 *
		 * Page Visibilty
		 * *********************************************************************************************************************************************
		 *
		 var timer = 0;
		 var PERIOD_VISIBLE = 1000;
		 var PERIOD_NOT_VISIBLE = 5 * 60000;
		 var userAway = false;

		 function onLoad() {
		 // timer = setInterval(checkUserStatus, (document.hidden) ? PERIOD_NOT_VISIBLE : PERIOD_VISIBLE);
		 if (document.addEventListener)
		 document.addEventListener("visibilitychange", visibilityChanged);
		 }

		 function visibilityChanged() {
		 clearTimeout(timer);
		 timer = setInterval(checkUserStatus, (document.hidden) ? PERIOD_NOT_VISIBLE : PERIOD_VISIBLE);
		 }

		 function checkUserStatus() {

		 var ustts = userAway ? "user_away" : "user_online";

		 var obj = {
		 cleintid : clientid,
		 service : "auth",
		 mesgtype : "request",
		 request : "user_status",
		 uid : loginuserid,
		 status : ustts,

		 }
		 wssend(obj)

		 // Check server for new messages
		 }

		 /*
		 * *******************************************************************************************************************************
		 *
		 * 									Request Drop Function: which drop the request on time out
		 *
		 * ********************************************************************************************************************************
		 */
		var timeOutList = {};
		function timeOut(id) {
			delete maptable[id];
		}

		function reqsucces_handle(id) {
			clearTimeout(timeOutList[id]);
			delete timeOutList[id];
		}

		/*
		 * *************************************************************************************************************************************
		 *
		 * 														Facebook Login setup
		 *
		 * **************************************************************************************************************************************
		 */
		var fbusername;
		var fbinfo = {};

		//= "steve.jobs";

		$('#uname').text("User").data({
			'uid' : loginuserid
		});

		var fbbtn = $("<button/>").append("<i class='facebook_24'></i><span> Connect with facebook</span>").addClass("facebook").bind('click', facebookLogin);
		var asi = $("<span/>").append("Sign In to antkorp").addClass("asi");
		var fr = $('<div id="logboard" class=" modal loginsts"></div>').append(asi).append('<div id="fb-root"></div>').append(fbbtn).appendTo("body");
		//.append('<div class="fb-login-button"  data-size="large" scope="email,user_birthday,user_work_history" >Login with Facebook</div>')
		$('<div id="logOverlay" class="overlay"></div>').appendTo('body')

		window.fbAsyncInit = function() {
			FB.init({
				appId : 102016259946645,
				cookie : true,
				xfbml : true,
				oauth : true
			});
			FB.getLoginStatus(function(response) {
				if (response.status === 'connected') {
					var uid = response.authResponse.userID;
					var accessToken = response.authResponse.accessToken;
					userfbCheck();
				} else if (response.status === 'not_authorized') {
					// the user is logged in to Facebook,
					// but has not authenticated your app
					//alert("not loggedin into app");
					$('#logboard, #logOverlay').fadeIn('fast');
				} else {
					// the user isn't logged in to Facebook.
					//alert("user not loggedin into facebook ");
					$('#logboard, #logOverlay').fadeIn('fast');
				}
			});

			FB.Event.subscribe('auth.login', function(response) {
				userfbCheck();

			});

			FB.Event.subscribe('auth.logout', function(response) {
				$('#logboard, #logOverlay').fadeIn('fast');
			});
		};
		// unused function
		function facebookLogin() {
			FB.login(function(response) {
				if (response.authResponse) {
					console.log('Authenticated!');
					// location.reload(); //or do whatever you want
				} else {
					console.log('User cancelled login or did not fully authorize.');
				}
			}, {
				scope : 'email,user_birthday,user_work_history'
			});
		}

		function userfbCheck() {
			$('#logboard, #logOverlay').hide();
			$(".akorp-ui").show();
			$('#menu').find('li[data-tabId="container"]').click();

			FB.api('/me', function(res) {
				console.log(res);

				var homeaddress = res.location;
				var work = res.work;
				fbinfo = {
					"dob" : res.birthday,
					"dept" : '',
					middle_name : "",
					mob : "",
					organization : "",
					jobtitle : "",
					homeaddress : "",
					"email" : res.email,
					"first_name" : res.first_name,
					"last_name" : res.last_name,
					"sex" : res.gender,
				};

				if (homeaddress) {
					fbinfo.homeaddress = homeaddress.name;
				}
				if (work) {
					if (work[0].employer)
						fbinfo.organization = work[0].employer.name;
					if (work[0].position)
						fbinfo.jobtitle = work[0].position.name;
				}

				var fbemail = res.email;
				var fname = res.last_name;
				fbusername = fbemail.substring(0, fbemail.lastIndexOf('@')) + res.id;
				//console.log(newfbusername);

				var fbData = {
					id : res.id,
					name : res.username,
					email : res.email,
					location : res.location,
				}

				$.ajax({
					url : "fblogin.php",
					type : "post",
					data : {
						userProfile : JSON.stringify(fbData)
					},

					success : function(response, textStatus, jqXHR) {

						var resp = JSON.parse(response);
						if (fbusername) {
							if (resp.message) {

								adduser(fbusername, fname);

							} else {
								if (!loginsuccess) {

									loginuser(fbusername);
								}
								prflview = false;
							}
						} else {
							console.log("User name not available");
						}
					},

					error : function(jqXHR, textStatus, errorThrown) {

						console.log("The following error occured: " + textStatus, errorThrown);
					},

					complete : function() {
						// enable the inputs
						console.log("user authentication successful.")

					}
				});

			});

		}


		$('#sobtn').bind('click', function() {
			if (logoutcall) {
				logoutuser(loginuserid);
			}
			//FB.logout(function(response) {
			window.location = "http://www.antkorp.in/"
			//});
		});
		( function(d) {
				var js, id = 'facebook-jssdk';
				if (d.getElementById(id)) {
					return;
				}
				js = d.createElement('script');
				js.id = id;
				js.async = true;
				js.src = "//connect.facebook.net/en_US/all.js";
				d.getElementsByTagName('head')[0].appendChild(js);
			}(document));

		/*
		 * ******************************************************************************************************************************************
		 *   																Licences
		 * ******************************************************************************************************************************************
		 */

		$(".licence-info").click(function() {
			$(".licence_dialog").show("scale");
		});

		$("#licence_close").click(function() {
			$(".licence_dialog").hide("scale");
		});
		/*
		 * ###########################################################################################################################
		 * 											Handle authentication requests.
		 *
		 * 													Service: AUTH
		 *
		 * ###########################################################################################################################
		 */

		/*$('#sobtn').bind('click', function() {
		 logoutuser(loginuserid);
		 });*/

		var usersList = {};
		var activedir, ghomedir;
		var activeuser;
		var logoutcall = false;
		var loginsuccess = false;
		var userFirstEntry = false;
		var firstVisit = {
			"container" : true,
			"dstore" : true,
			"kons" : true,
			"planner" : true,
			"pinit" : true,
			"men" : true,
			"pdt" : true
		};

		$('#menu li').click(function() {
			$(this).siblings('li').removeClass('active').end().addClass('active');
			var tabId = $(this).data("tabid");
			//console.log(tabId);

			if (tabId == "kons") {
				$(".tgp-top-border").css({
					"width" : "88%",
					"border-top-left-radius" : "3px"
				});

			} else {
				$(".tgp-top-border").css({
					"width" : "94%",
					"border-top-left-radius" : "none"
				})
			}

			$(".card").hide();
			$(".tourcard").hide();
			if (firstVisit[tabId]) {
				//firstVisit[tabId] = false;

				if (tabId == "container") {
					$(".tourcard").css({
						"top" : "10%",
						"left" : "30%"
					}).show();
					$(".card1").show("scale");

				} else if (tabId == "dstore") {
					$(".tourcard").css({
						"top" : "50%",
						"left" : "60%"
					}).show();
					$(".card4").show("scale");

				} else if (tabId == "kons") {
					$(".tourcard").css({
						"top" : "20%",
						"left" : "40%"
					}).show();
					$(".card2").show("scale");

				} else if (tabId == "planner") {
					$(".tourcard").css({
						"top" : "50%",
						"left" : "20%"
					}).show();
					$(".card5").show("scale");

				} else if (tabId == "pinit") {
					$(".tourcard").css({
						"top" : "40%",
						"left" : "60%"
					}).show();
					$(".card6").show("scale");

				}
			}

			$(".content").children().hide().end().children('#' + tabId).show();
		});

		$("span.tourclsbtn").bind("click", function() {
			var id = $(".card:visible").data("cardid");
			firstVisit[id] = false;

			$(".card").hide();
			$(".tourcard").hide();

		});

		/*	var card1 = $("<div/>").attr("data-cardid", "container").addClass("card vlt card1").append("Your private folder. Drag files and folders to upload. ").hide();
		 var card2 = $("<div/>").attr("data-cardid", "kons").addClass("card  card2").append("Do not use email for discussions any more, use our konversations to discuss.").hide();
		 var card3 = $("<div/>").attr("data-cardid", "men").addClass("card  card3").append("Unified communications built right in to the product. make video calls, type instant messages and share your desktop.").hide();
		 var card4 = $("<div/>").attr("data-cardid", "dstore").addClass("card  card4").append("Enterprise grade document management system with version control and many more features. ").hide();
		 var card5 = $("<div/>").attr("data-cardid", "planner").addClass("card  card5").append("Plan your meetings, organize your stuff with our planner.").hide();
		 var card6 = $("<div/>").attr("data-cardid", "pinit").addClass("card  card6").append("Bulletin board for your group.").hide();

		 $("<div/>").append().addClass("akorp-ui tourcard").appendTo("body").append(card1).append(card2).append(card3).append(card4).append(card5).append(card6).append(closecard).hide();
		 *
		 $('#menu').find('li[data-tabId="container"]').click();

		 /*function testTour() {
		 $(".topbar").css("z-index", 100000);
		 var cvc = 0;
		 var card1 = $("<div/>").addClass("card vlt card1").append("It is your personal directory here you can manage files. simply Drop your files here.");
		 var card2 = $("<div/>").addClass("card kon card2").append("Discuss anything and everything.Share opinions and comments.").hide();
		 var card4 = $("<div/>").addClass("card kon card4").append("It is version enabled document management file system. Here you can store confidential file.").hide();
		 var card5 = $("<div/>").addClass("card kon card5").append("Plan your date. Schedule your appointments and meetings.").hide();
		 var card6 = $("<div/>").addClass("card kon card5").append("").hide();

		 var card3 = $("<div/>").addClass("card kon card3").append("Here is your group members! you can communicate with them using hover tools.").hide();
		 $("<div/>").addClass("overlay tour").appendTo("body")
		 $("<div/>").append().addClass("modal vaultcard").appendTo("body").append(card1).append(card2).append(card3).append(card4);
		 var nextbtn = $("<div/>").addClass("modal tourNxtBtn btn redbtn").append("Next").appendTo("body").bind('click', function() {
		 //$(".card").hide("explode");

		 cvc++
		 if (cvc == 1) {
		 $(".card1").hide("explode");
		 $(".card2").show("scale");
		 $('#menu').find('li[data-tabId="kons"]').click();
		 } else if (cvc == 2) {
		 $(".card2").hide("explode")
		 $(".card3").show("scale");
		 $(".topbar").css("z-index", 10);
		 $(".clbar").css("z-index", 100000)
		 //$(".vaultcard").css("left","80%");
		 $(this).text('End')
		 } else {
		 $(".vaultcard, .tour, .modal").hide();
		 $(".clbar").css("z-index", 1)
		 }
		 });

		 }
		 */

		function handleAuthMessage(msg_obj) {

			var svr_cmds = msg_obj;

			//console.log(svr_cmds);
			reqsucces_handle(svr_cmds.cookie);
			if (svr_cmds.mesgtype == "event") {
				if (svr_cmds.eventtype == "new_user") {

					usersList[svr_cmds.user.uid] = svr_cmds.user;
					addContactUser(usersList[svr_cmds.user.uid]);
					//sortContacts();
				} else if (svr_cmds.eventtype == "status_update") {

					$(".clist").trigger('userstatusupdate', [svr_cmds.status, svr_cmds.user]);
				}
			} else {

				switch(maptable[svr_cmds.cookie]) {
					case "activeuser":
						logoutcall = true;
						usersList[svr_cmds.user.uid] = svr_cmds.user;
						activeuser = svr_cmds.user;
						activedir = activeuser.homedir;
						loginuserid = activeuser.uid;

						if (userFirstEntry) {
							setuser(fbinfo);
							prflview = false;
							userFirstEntry = false;
						}

						/*
						 * update the active user info in UI.
						 */

						$('#uname').text(activeuser.first_name || "no name").data({
							'username' : activeuser.uname,
							'uid' : activeuser.uid
						}).attr('title', "Click to change the profile");

						$('#activeuserimg').attr("src", activeuser.image_small || "css/images/user32.png");

						$("#home").attr('data-path', activedir);
						$("#dstore_home").attr('data-path', activedir);

						getgroup(activeuser.gid);

						/*
						 * send requests for directory elements of user.
						 */

						var guid = createUUID();
						dir_json = {
							clientid : clientid,
							mesgtype : "request",
							service : "fmgr",
							request : "getdir",
							cookie : guid,
							dname : activedir

						}
						refresh();
						maptable[dir_json.cookie] = 'tree';

						//testTour();

						/*	var guid = createUUID();
						 dstoreObj = {
						 clientid : clientid,
						 mesgtype : "request",
						 service : "dstore",
						 request : "getdir",
						 cookie : guid,
						 dname : activedir
						 }
						 dstoreRefresh();
						 maptable[dstoreObj.cookie] = 'tree';*/

						break;
					case 'getuser':
						if (svr_cmds.mesgtype == "response") {
							usersList[svr_cmds.user.uid] = svr_cmds.user;
							showProfile(svr_cmds.user);
							if (svr_cmds.user.uid == loginuserid) {
								$('#uname').text(svr_cmds.user.first_name || "no name");
								$('#activeuserimg').attr("src", activeuser.image_small || "css/images/user32.png");
							}
							if (svr_cmds.user.uid != loginuserid) {
								addContactUser(usersList[svr_cmds.user.uid]);

							}
						} else {
							console.log(svr_cmds);
						}
						break;

					case 'setuser':
						if (svr_cmds.status == "success") {
							//prflview = true;
							getuser(loginuserid);
						}
						break;

					case 'adduser':

						if (svr_cmds.status == "success") {
							userFirstEntry = true;
							if (!loginsuccess) {
								loginuser(fbusername);
							}
						}
						break;
					case "getgroup":
						//console.log(svr_cmds);
						var members = svr_cmds.group.members;
						ghomedir = svr_cmds.group.homedir;
						for (var i = 0; i < members.length; i++) {
							if (!usersList[members[i]]) {
								getuser(members[i]);
							}
						}

						break;

					default:
						console.log("Request Timed out:");
						console.log(svr_cmds);
				}
			}
		}

		function getgroup(grpid) {
			var unique = createUUID();
			var getgrp_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "auth",
				request : "getgroup",
				cookie : unique,
				uid : 1000,
				gid : grpid,
			};

			wssend(getgrp_obj);
			maptable[getgrp_obj.cookie] = 'getgroup';
		}

		function loginuser(userId) {
			var guid = createUUID();
			var loginuser_obj = {
				clientid : clientid,
				mesgtype : "request",
				request : "login",
				service : "auth",
				uname : userId,
				cookie : guid,
			}
			wssend(loginuser_obj);
			maptable[loginuser_obj.cookie] = 'activeuser';
			loginsuccess = true;
		}

		function logoutuser(userId) {
			var guid = createUUID();
			var loginuser_obj = {
				clientid : clientid,
				mesgtype : "request",
				request : "logout",
				service : "auth",
				uid : userId || 0,
				cookie : guid,
			}
			wssend(loginuser_obj);
			maptable[loginuser_obj.cookie] = 'activeuser';
			logoutcall = false;
		}

		function getuser(userId) {
			var unique = createUUID();
			var getuser_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "auth",
				request : "getuser",
				cookie : unique,
				uid : 0,
				gid : 1000,
				uid : userId,
			}
			wssend(getuser_obj);

			maptable[unique] = "getuser";
			timeOutList[unique] = setTimeout(timeOut, 30 * 1000, unique);
		}

		function setuserbymodified(user) {
			var dept = $('input#dept').val(), dob = $('input#dob').val(), email = usersList[loginuserid].email, fname = $('input#first_name').val(), haddr = $('#haddr').val(), jobtl = $('input#jobtitle').val(), lname = $('input#last_name').val(), mname = $('input#middle_name').val(), mob = $('input#mobile').val(), org = $('input#org').val(), usex = $('#sex').val(), waddr = $('#waddr').val();

			var userObj = {
				"dept" : dept,
				"dob" : dob,
				"email" : email,
				"first_name" : fname,
				"homeaddress" : haddr,
				"jobtitle" : jobtl,
				"last_name" : lname,
				"middle_name" : mname,
				"mob" : mob,
				"organization" : org,
				"sex" : usex,

			}
			prflview = true;
			setuser(userObj);

		}

		function setuser(userObj) {
			//send request to set the user info of userID.
			//getting values from fields

			for (var key in userObj) {
				if (!userObj[key]) {
					userObj[key] = '';
				}
			}

			var unique = createUUID();
			var setUser_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "auth",
				request : "setuser",
				cookie : unique,
				uid : usersList[loginuserid].uid,
				gid : 1000,
				user : userObj
			}

			wssend(setUser_obj);
			maptable[unique] = "setuser";
			timeOutList[unique] = setTimeout(timeOut, 30 * 1000, unique);

		}

		function adduser(userID, fname) {
			//send the request to add user.
			//after success of the add user u need to send get request.
			var unique = createUUID();
			var adduser_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "auth",
				request : "adduser",
				cookie : unique,
				uid : 0,
				gid : 1000,
				uname : userID,
				gname : 0,
				first_name : fname,
			}
			wssend(adduser_obj);
			maptable[unique] = "adduser";
			timeOutList[unique] = setTimeout(timeOut, 30 * 1000, unique);

		}

		/*
		 * *******************************************************************************************************************************
		 *
		 * 															Profile Management
		 *
		 * *******************************************************************************************************************************
		 */
		var prflview = false;

		function showProfile(user) {
			if (prflview) {
				viewChange(user)
				var userprofile = $('#userprofile_view').show();
				$('<div/>').addClass('overlay').append('#userpofile_view').appendTo('body');
				prflview = false;
			}
		}


		$('#userinfo').bind('click', function() {

			viewChange(usersList[loginuserid])
			var userprofile = $('#userprofile_view').show();
			$('<div/>').addClass('overlay').append('#userpofile_view').appendTo('body');

		});

		$(".stts_msg").bind('click', function(e) {
			e.stopPropagation();
			var stts = $(this).attr("data-stts");
			$("#status_opts li").removeClass("current_status");
			$("#status_opts li[data-opt='" + stts + "']").addClass("current_status");

			$("#status_opts").slideDown();
			//.show().css("display","block");
		});

		$("#status_opts li").bind("click", function(e) {
			var stts = $(this).data("opt");
			$(".stts_msg").attr("data-stts", stts);
			var obj = {
				clientid : clientid,
				service : "auth",
				mesgtype : "event",
				eventtype : "status_update",
				user : loginuserid,
				status : stts
			}
			wssend(obj);
		})
		function closeModal() {
			$('.modal').fadeOut('slow', function() {
				$('.modal').hide();
				$('.overlay').hide();
			});
		}


		$('#profileSave').hide();
		$('#profileEditCancel').hide();

		function profileSave() {
			if (!picChanged) {
				setuserbymodified();
			} else {
				canv2.toBlob(function(blob) {
					profilePicUploadWorker.port.postMessage({
						'mesgtype' : 'file_list',
						'files' : blob,
						'dname' : activedir + "/profile.png",
						clientid : clientid,
					});

				}, "image/png");
				picChanged = false;
			}
			//viewChange();
			//$('.uinfo').attr('contenteditable', false).blur().removeClass('editbox');
		}

		function profileEditCancel() {
			viewChange(usersList[loginuserid]);

		}

		function viewChange(User) {
			var cuser = User;
			for (var key in cuser) {
				if (cuser[key] == "undefined") {
					cuser[key] = "";
				}
				if (!cuser[key]) {
					cuser[key] = ""
				}
			}

			$('#profileEditCancel').hide();
			$('#profileSave').hide();
			$('#profileEdit').hide();
			if (cuser.uid == loginuserid) {
				$('#profileEdit').show();
			}
			$('#profileClose').show();
			$('#changePic').css('display', 'none');
			$('#usrpic').attr('src', cuser.image_large);
			//$('.uinfo').attr('contenteditable', false).blur().removeClass('editbox');
			//$('.prfl_uname').text(User.uname);
			$('.prfl_fname').text(cuser.first_name);
			$('.prfl_mname').text(cuser.middle_name);
			$('.prfl_lname').html(cuser.last_name);
			$('.prfl_sex').html(cuser.sex);
			$('.prfl_dob').html(cuser.dob);
			//$('.prfl_email').html(User.email);
			$('.prfl_mobile').html(cuser.mob);
			$('.prfl_haddr').html(cuser.homeaddress);
			$('.prfl_designation').html(cuser.jobtitle);
			$('.prfl_dept').html(cuser.dept);
			$('.prfl_comp').html(cuser.organization);
			//$('.prfl_waddr').html(User.workaddress);
		}

		function profileChange() {
			//$('#userprofile_view').hide();
			//$('#userprofile').show();
			/*
			 * Changing text to controls
			 */
			var sampleUser = usersList[loginuserid];
			console.log(sampleUser);

			console.log(sampleUser.work);

			//$('.prfl_uname').html('<input type="text"  id="user_name" value="' + sampleUser.uname + '"  required>');
			$('.prfl_fname').html('<input type="text" id="first_name" name="first_name" value="' + sampleUser.first_name + '" placeholder="First Name" required>');
			$('.prfl_mname').html('<input type="text" id="middle_name" name="middle_name" value="' + sampleUser.middle_name + '" placeholder="Middle Name" >');
			$('.prfl_lname').html('<input type="text" id="last_name" name="last_name" value="' + sampleUser.last_name + '" placeholder="Last Name" required>');
			$('.prfl_sex').html('<select id="sex"><option>Male</option><option>Female</option></select>');
			$('.prfl_dob').html('<input type="date" id="dob" name="dob" value="' + sampleUser.dob + '" placeholder="Date of Birth" required>');
			//$('.prfl_email').html('<input type="email" id="pemail" name="pemail" value="' + sampleUser.email + '" placeholder="Primary Email Id" required>');
			$('.prfl_mobile').html('<input type="text" id="mobile" name="mobile_no" value="' + sampleUser.mob + '" placeholder="Mobile" required>');
			$('.prfl_haddr').html('<textarea rows="5" cols="25" id="haddr" value="">' + sampleUser.homeaddress + '</textarea>');
			$('.prfl_designation').html('<input type="text" id="jobtitle" name="jobtitle" value="' + sampleUser.jobtitle + '" placeholder="Designation" required>');
			$('.prfl_dept').html('<input type="text" id="dept" name="dept" value="' + sampleUser.dept + '" placeholder="Department Name" required>');
			$('.prfl_comp').html('<input type="text" id="org" name="org" value="' + sampleUser.organization + '" placeholder="Company Name" required>');
			//$('.prfl_waddr').html('<textarea rows="5" cols="25" id="waddr" value="" >' + sampleUser.work + '</textarea>');

			$('#sex').val(sampleUser.sex);
			$('#changePic').css('display', 'block');

			/*
			 * Displaying neccessary buttons only
			 */
			$('#profileEdit').hide();
			$('#profileClose').hide();
			$('#profileSave').show();
			$('#profileEditCancel').show();

		}

		function profilePicHandler() {

			$('#userprofile_view').hide();
			$('#profilePicAlter').show();
			ctx1.clearRect(0, 0, canv1.width, canv1.height);
			ctx2.clearRect(0, 0, canv2.width, canv2.height);
			$('#pic').remove();
			surface.removeChild(surface.childNodes[0]);
			$('#surface').append("<p>Drop Photo Here</p>");
			resize(surface, 400, 400);

		}


		$('#profileClose').bind('click', closeModal);
		$('#profileEdit').bind('click', profileChange);
		$('#profileSave').bind('click', profileSave);
		$('#profileEditCancel').bind('click', profileEditCancel);
		$('#changePic').bind('click', profilePicHandler)

		/*
		 * ***************************************************************************************************************************************
		 *
		 * 															Profile Picture upload
		 *
		 * ***************************************************************************************************************************************
		 */

		var profilePicUploadWorker = new SharedWorker("profilePic_upload.js");
		profilePicUploadWorker.port.start();
		profilePicUploadWorker.port.onerror = akorp.werror;
		profilePicUploadWorker.port.onmessage = profilePicOnmessageHandler;

		function profilePicOnmessageHandler(e) {
			var dat = e.data.obj;
			if (!e.data.obj) {
				//console.log(e.data);
			} else if (dat.mesgtype == 'request' || dat.mesgtype == 'cancel') {
				wssend(dat);

				maptable[dat.cookie] = 'picUpload';
			} else if (dat.mesgtype == 'complete') {

				setuserbymodified();

				/*
				 * Here we have to send the get request to the server.
				 * we have to display animation for uploading image.
				 */
			}

		}

		var cropWidget = document.getElementById('cropWidget');
		var surface = document.getElementById('surface');
		var canv1 = document.getElementById('canv1');
		var canv2 = document.getElementById('canv2');
		var imageSubmit = document.getElementById('imageSubmit');
		var ctx1 = canv1.getContext('2d');
		var ctx2 = canv2.getContext('2d');
		var origin = document.getElementById('profilePicAlter');
		var picChanged = false;

		function resize(comp, width, height) {
			comp.width = width;
			comp.height = height;
			comp.style.width = width + 'px';
			comp.style.height = height + 'px';
		}

		function displayImage(img) {
			var w = img.width < 500 ? img.width : 500;
			var h = img.height < 500 ? img.height : 500;
			resize(img, w, h);
			resize(canv1, w, h);
			resize(surface, w, h);
			resize(cropWidget, w, h);
			while (surface.childNodes[0])
			surface.removeChild(surface.childNodes[0]);
			surface.appendChild(img);
			ctx1.drawImage(img, 0, 0, w, h);
			jQuery("#" + img.id).Jcrop({
				aspectRatio : 1,
				onSelect : cropImage,
				setSelect : [200, 200, 50, 50],
				bgOpacity : .3,
				bgColor : 'white'

			});
		}

		function loadImg(imgFile) {
			/*
			 * check for image type
			 * If Not return
			 *
			 */
			if (!imgFile.type.match(/image.*/))
				return;

			var img = document.createElement("img");
			img.id = "pic";
			img.file = imgFile;
			/*
			 * create the image element
			 * read the uploaded file then  display
			 */
			var reader = new FileReader();
			reader.onload = function(e) {
				img.onload = function() {
					displayImage(img);
				};
				img.src = e.target.result;

			};
			reader.readAsDataURL(imgFile);
		}

		function cropImage(c) {
			var w = c.x2 - c.x;
			var h = c.y2 - c.y;

			ctx2.drawImage(canv1, c.x, c.y, w, h, 0, 0, 200, 230);

		}

		function uploadSelection() {
			var imgData = document.getElementById('canv2').toDataURL("image/png");
			picChanged = true;
			$(".userPic").attr('src', imgData);
			$("#profilePicAlter").hide();
			$("#userprofile_view").show();

			return false;
		}

		function picChangeCancel() {
			picChanged = false;
			$("#profilePicAlter").hide();
			$("#userprofile_view").show();
			//ctx1.clearRect(0, 0, canv1.width, canv1.height);
			//ctx2.clearRect(0, 0, canv2.width, canv2.height);
			//$('#pic').remove();
			//surface.removeChild(surface.childNodes[0]);
			//$('#surface').append("<p>Drop Photo Here</p>");
			//resize(surface, 400, 400);
		}


		surface.addEventListener("dragover", function(e) {
			e.preventDefault();
		}, true);
		surface.addEventListener("drop", function(e) {
			e.preventDefault();
			loadImg(e.dataTransfer.files[0]);
		}, true);

		$('#imageSubmit').bind('click', uploadSelection);
		$("#picChangeClose").bind('click', picChangeCancel)

		/*
		 *
		 * feedback
		 *
		 */
		$('.feedback').bind('click', function() {
			$("<div/>").append("<p>Thank you for visiting us.</p><textarea rows=9 cols=30></textarea>").css({
				"font-size" : "15px",
			}).attr({
				'title' : "Feedback"
			}).dialog({
				height : 300,
				width : 350,
				modal : true,
				buttons : {
					"Send" : function(e) {
						var cmnt = $(this).children("textarea").val();
						if (cmnt) {
							var feedback = {
								id : loginuserid,
								name : usersList[loginuserid].first_name,
								email : usersList[loginuserid].email,
								stmt : cmnt,
							}
							$.ajax({
								url : "feedback.php",
								type : "post",
								data : {
									userFeedback : JSON.stringify(feedback)
								},

								success : function(response, textStatus, jqXHR) {

									console.log("feedback recorded successfully " + response.message)
								},

								error : function(jqXHR, textStatus, errorThrown) {

									console.log("The following error occured while recording feedback : " + textStatus, errorThrown);
								},

								complete : function() {
									// enable the inputs
									//console.log("user authentication successful.")

								}
							});
						}

						$(this).dialog("close").remove();
					},
					"cancel" : function() {
						$(this).dialog("close").remove();
					}
				}
			})
		})
		/*
		 **************************************************************************************************************************************
		 *
		 * 	                                                              CONTACT LIST : SIDEBAR
		 *
		 * ************************************************************************************************************************************
		 */

		var hidetoolstimer;
		var uprofile = $('<span class="uprfl"></span>').attr('title', 'Profile');
		var chat = $('<span class="uchat"></span>').attr('title', 'Chat');
		//var audiocall = $('<span class="uaudcal"></span>').attr('title', 'Audio Call');
		var vidcall = $('<span class="uvidcal"></span>').attr('title', 'Video Call');
		var scrshar = $('<span class="uscrshar"></span>').attr('title', 'Grab Desktop');
		var umail = $('<span class="umail"></span>').attr('title', 'Send Mail');
		var specname = $('<div></div>').addClass('specname');

		//.append(audiocall)

		$("<div class='usertools'></div>").append(specname).append(uprofile).append(chat).append(vidcall).append(scrshar).append(umail).appendTo('body');

		$("#cnsearch").bind("keyup", contactSearch)

		function contactSearch() {
			var str = $(this).val();
			var list = $(".clist").children("div.contact");
			list.hide();
			if (str) {
				$.each(list, function(item) {
					var cname = $(this).data("contname");
					if (cname.toUpperCase().match(str.toUpperCase())) {
						$(this).show();
					}
				})
			} else {
				list.show();
			}
		}

		function addContactUser(user) {
			var uimg = $('<div/>').addClass('uimg');
			$('<img />').attr({
				'src' : user.image_small || 'css/images/user32.png',
				'height' : 32,
				'width' : 32
			}).appendTo(uimg);
			var sid;
			if (user.status == "online") {

				sid = 1;
			} else if (user.status == "offline") {

				sid = 2
			}

			//$("#contacts").append("<option value='" + user.first_name + " " + user.last_name + "'>");

			$('<span />').addClass('ustatus').addClass(user.status).appendTo(uimg);
			$('<div />').addClass('contact user').attr({
				'data-uid' : user.uid,
				"data-status" : user.status,
				"data-sid" : sid,
				"data-contname" : user.first_name + " " + user.last_name,
			}).append(uimg).appendTo(".clist").draggable({
				containment : 'document',
				appendTo : "body",
				helper : 'clone',
				revert : 'Invalid',
				zindex : 1000000
			}).bind("drag", function(event, ui) {
				ui.helper.css("background-color", "orange");
			}).hover(function(e) {
				var offset = $(this).offset();

				clearTimeout(hidetoolstimer);

				$('.usertools').children('.specname').html(user.first_name).end().children('.uprfl').unbind('click').bind('click', user.uid, profileinit).end().children('.uchat').unbind('click').bind('click', {
					'uid' : user.uid
				}, chatinit).end().children('.uvidcal').unbind('click').bind('click', {
					"hisid" : user.uid,
					"hisname" : usersList[user.uid].first_name,
					"status" : usersList[user.uid].status
				}, dialUser).end().children('.uscrshar').unbind('click').bind('click', userScreenShareRequest).end().children('.umail').unbind('click').bind('click', userMailClient).end().css({
					top : offset.top + 45,
					left : offset.left
				}).fadeIn();
				//$(this).append("<div class='usertools'>hi this is hover div</div>").css({width:"100px",overflow:"hidden"});
			}, function() {
				hidetoolstimer = setTimeout(displaytools, 500);
			});
			sortContacts();

		}


		$(".clist").bind("userstatusupdate", function(e, status, uid) {
			var statusupdate, sid;
			if (status == "online" || status == "available") {
				statusupdate = "online";
				sid = 1;
			} else if (status == "offline" || status == "invisible") {
				statusupdate = "offline";
				sid = 4
			} else if (status == "away") {
				statusupdate = "away";
				sid = 3
			} else if (status == "donotdisturb") {
				statusupdate = "donotdisturb";
				sid = 2
			}

			usersList[uid].status = statusupdate;
			$(this).find("div.contact[data-uid=" + uid + "]").attr({
				"data-status" : statusupdate,
				"data-sid" : sid
			}).find(".ustatus").removeClass("offline online donotdisturb away").addClass(statusupdate);

			setTimeout(sortContacts, 5000);

			if (statusupdate == "donotdisturb")
				statusupdate = "Busy";

			noty({
				layout : 'bottomRight',
				theme : 'default',
				type : 'alert',
				text : usersList[uid].first_name + " is " + statusupdate,
				timeout : 10000
			});
		}).bind('hover', function() {
			if (firstVisit["men"]) {
				firstVisit["men"] = false;
				$(".tourcard").css({
					"top" : "40%",
					"left" : "70%"
				}).show();
				$(".card").hide();
				$(".card3").show("scale");

			}
		})
		function displaytools() {
			$('.usertools').hide();
		}

		function pendingfunctionalities() {
			noty({
				layout : 'bottomRight',
				theme : 'default',
				type : 'error',
				text : 'oops! We are still working on it! <br/> Stay tuned...',
				timeout : 10000
			});
		}

		function userMailClient(e) {
			pendingfunctionalities();

		}

		function userScreenShareRequest(e) {
			pendingfunctionalities();
		}

		function profileinit(e) {
			prflview = true;
			var userid = e.data;
			//$(this).parents().find(".user").data('uid');
			showProfile(usersList[userid]);
		}


		$('.usertools').hover(function(e) {
			clearTimeout(hidetoolstimer);

			$('.usertools').show();
		}, function(e) {
			hidetoolstimer = setTimeout(displaytools, 500);
		});

		function sortContacts() {
			var contacts = $('div.clist'), cont = contacts.children('div.contact');

			cont.sort(function(a, b) {
				var astts = $(a).data('sid');
				var bstts = $(b).data('sid')
				//return astts > bstts;
				return (astts > bstts) ? (astts > bstts) ? 1 : 0 : -1;
				//return a.dataset.sid >b.dataset.sid;
			}).appendTo(contacts);

		}

		/*$('.user').draggable({
		 containment : 'document',
		 appendTo : "body",
		 helper : 'clone',

		 zindex : 1000000
		 }).bind("drag", function(event, ui) {
		 ui.helper.css("background-color", "red");
		 });

		 $(".contact").hover(function(e) {
		 var offset = $(this).offset();

		 clearTimeout(hidetoolstimer);

		 $('.usertools').css({

		 top : offset.top + 45,
		 left : offset.left
		 }).show();
		 //$(this).append("<div class='usertools'>hi this is hover div</div>").css({width:"100px",overflow:"hidden"});
		 }, function() {
		 hidetoolstimer = setTimeout(displaytools, 1000);
		 });
		 */

		/*
		 * ########################################################################################################################################
		 * File Manager || vault script
		 * XXX:Pending Features 1.Drag and Drop file in UI
		 *
		 *                                                                   Service: FMGR
		 *
		 *#########################################################################################################################################
		 */

		function handleFmgrGroupChange(e) {
			var chome = $(this).attr("data-currenthome"), homedir;

			if (chome == "phome") {
				homedir = ghomedir;
				$(this).attr("data-currenthome", "ghome").addClass("groupactive");
			} else if (chome == "ghome") {
				homedir = activedir;
				$(this).attr("data-currenthome", "phome").removeClass("groupactive");
			}

			var guid = createUUID();
			dir_json.service = "fmgr";
			dir_json.cookie = guid;
			dir_json.dname = homedir;

			$('span#home').attr('data-path', homedir).parent('li').addClass('node_active');

			$('span#home').parent().next("ul").remove();

			refresh();
			maptable[dir_json.cookie] = 'tree';

		}


		$("#ghome").bind('click', handleFmgrGroupChange);

		akorp.dwmessage = function(e) {
			var down_data = e.data;
			if (!down_data.file) {
				console.log(down_data);
			} else if (down_data.file.mesgtype == 'ack' || down_data.file.mesgtype == 'request' || down_data.file.mesgtype == 'cancel') {
				wssend(down_data.file);

				maptable[down_data.file.cookie] = 'download';
				dpr.setProgress(down_data.percent)
			} else if (down_data.file.mesgtype == 'save') {
				dpr.setProgress(down_data.percent)
				var dfname = down_data.file.dfname.substring(down_data.file.dfname.lastIndexOf('/') + 1, down_data.file.dfname.length);
				//var bb = new WebKitBlobBuilder;
				//bb.append(down_data.file.blob);
				//window.saveAs(down_data.file.blob, dfname);
				saveAs(down_data.file.fl, dfname);
				$('#dloads').find('div:eq(0)').remove();
				if ($('#dloads div').length == 0) {
					$('#downloads').jqxWindow('hide');
				}
			}
		};
		akorp.uwmessage = function(e) {
			var dat = e.data.obj;
			//console.log(dat);
			if (!e.data.obj) {
				console.log(e.data);
			} else if (dat.mesgtype == 'request' || dat.mesgtype == 'cancel') {
				var pcnt = e.data.prct;
				//console.log(Math.round(pcnt));
				//$('#upload_status').find('div[data-path="' + dat.fname + '"]').find('progress').val(Math.round(pcnt) / 100);
				upr.setProgress(Math.round(pcnt) / 100);
				/*if (Math.round(pcnt) == 100) {
				 //$('#upload_status').find('div[data-path="' + dat.fname + '"]').remove();
				 $('#upload_status').find('div:eq(0)').remove();
				 if ($('#upload_status div').length == 0)
				 $('#uploadwindow').jqxWindow('hide');
				 }*/

				wssend(dat);

				maptable[dat.cookie] = 'fmgrUpload';
			} else if (dat.mesgtype == 'complete') {
				$('#upload_status').find('div:eq(0)').remove();
				if ($('#upload_status div').length == 0) {

					$('#uploadwindow').jqxWindow('hide');
					refresh();
				}

			}
		};

		var Dworker = new SharedWorker('Download_worker.js');
		Dworker.port.start();
		Dworker.port.onerror = akorp.werror;
		Dworker.port.onmessage = akorp.dwmessage;

		var worker = new SharedWorker('Upload_worker.js');
		worker.port.start();
		worker.port.onerror = akorp.werror;
		worker.port.onmessage = akorp.uwmessage;

		var fmgrClipboard = null;

		function handleFmgrMessage(msg_obj) {

			var svr_cmds = msg_obj;

			if (svr_cmds.mesgtype == "error") {
				$('<div />').append("<p>" + svr_cmds.estring + "</p>").css({
					color : 'red'
				}).dialog({
					position : ['right', "bottom"],
					closeOnEscape : false,
					buttons : {
						'OK' : function() {
							$(this).dialog('close').remove();
						}
					},
					dialogClass : 'error',
				})
			} else {

				switch(maptable[svr_cmds.cookie]) {
					case 'window':
						var windowid = window_manager.mapRequest[svr_cmds.cookie];
						var wndelem = window_manager.getWindowById(windowid);
						wndelem.updateHandle(svr_cmds);
						break;
					case 'fmgrUpload':
						worker.port.postMessage(svr_cmds);
						break;
					case 'picUpload':
						profilePicUploadWorker.port.postMessage(svr_cmds);
						break;
					case 'download':
						var strdata = svr_cmds.data;
						svr_cmds.data = window.atob(strdata);
						Dworker.port.postMessage({
							obj : svr_cmds
						});
						break;
					case 'tree':

						form_tree(svr_cmds.direlements, expander);

						break;

					case 'search':
						handleFmgrSearchResults(svr_cmds);
						break;
					case 'question':

						if (!svr_cmds.status) {
							var button = $('<input type="checkbox" id="check" /><label for="check">Apply this answer for all</label>');
							$('#check').button();

							var q_obj = {
								clientid : clientid,
								mesgtype : "answer",
								service : "fmgr",
								cookie : svr_cmds.cookie,
								//answer://yes/no/yesall/noall
							};

							$('<div/>').append('<p>' + svr_cmds.estring + '</p><br/>').append(button).addClass('ui-state-highlight').dialog({
								resizable : false,
								height : 'auto',
								modal : true,
								position : ['right', "bottom"],
								closeOnEscape : false,
								open : function(event, ui) {
									$(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
								},
								buttons : {
									"Yes" : function() {

										if (!$('#check').is(':checked'))
											q_obj.answer = 'yes';
										else
											q_obj.answer = 'yesall'

										wssend(q_obj);

										maptable[q_obj.cookie] = 'question';
										$(this).dialog("close");
									},
									'No' : function() {

										if (!$('#check').is(':checked'))
											q_obj.answer = 'no';
										else
											q_obj.answer = 'noall'
										wssend(q_obj);

										maptable[q_obj.cookie] = 'question';

										$(this).dialog("close");

									}
								}
							});
						} else {
							if (svr_cmds.status != "fail") {
								refresh();
							}
							FODialog.dialog('close');
							//console.log(svr_cmds.status);
						}
						break;
					case 'remove':
						break;
				}

			}

		}

		function handleFileWriter(e) {
			var list = e.data.list;
			$.each(list, function(i, v) {
				//console.log(v);
				var fname = $(v).data('path');
				var size = $(v).data('fsize');
				var dfname = fname.substring(fname.lastIndexOf('/') + 1, fname.length);
				if (!$(v).data('dir')) {

					$('#downloads').jqxWindow('show');
					$('#downloads').jqxWindow('bringToFront');
					var guid = createUUID();

					var write_obj = {//json format
						clientid : clientid,
						mesgtype : "request",
						service : "fmgr",
						request : "read",
						cookie : guid,
						fname : fname,
						size : 1024,
					};
					Dworker.port.postMessage({
						obj : write_obj,
						siz : size
					});
					$('#dloads').append('<div class="download_file">' + dfname + '<span class="cancel dc" data-fname="' + fname + '" data-cookie>Cancel</span></div>');
				} else {
					var data = "<strong>Directory is not supported!</strong><br><b>" + dfname + "</b> cannot be download.";

					$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>' + data + '</p>').dialog({
						resizable : false,
						height : 140,
						position : ['right', "bottom"],
						//modal : true,
						buttons : {
							OK : function() {
								$(this).dialog("close");
							}
						}
					});

				}
			});
		}


		$('.dc').live('click', function() {
			var fname = $(this).data('fname');

			$(this).parent().remove();
			if ($('#dloads div').length == 0)
				$('#downloads').jqxWindow('hide');

			var write_obj = {//json format
				clientid : clientid,
				mesgtype : "cancel",
				service : "fmgr",
				request : "read",
				fname : fname,
			};
			Dworker.port.postMessage({
				obj : write_obj

			});

		});

		function sendreq(node_file_li) {
			tot_elems = [];
			var $this = node_file_li;
			$('#location').attr('value', 'antkorp:/' + $this.attr('data-path'));
			dir_json.cookie = createUUID();
			dir_json.dname = $this.attr('data-path');
			dir_json.service = "fmgr";

			wssend(dir_json);

			maptable[dir_json.cookie] = "tree"//dir_json.request;
			$('#file-list').empty();
		}

		function form_tree(svr_msg, expndr) {
			var msg = svr_msg;

			var $trash = $('li.node_active');
			var $list = $("ul", $trash).length ? $("ul", $trash) : $("<ul/>").appendTo($trash);
			$list.hide();
			for (var i = 0; i < msg.length; i++) {
				if (msg[i].fname.indexOf('.') != 0) {
					if (msg[i].isdir == 'true' && !expndr) {

						var selectedItem = $('#nodes').jqxTree('selectedItem');
						var nodeHtml = '<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path="' + dir_json.dname + '/' + msg[i].fname + '" >' + msg[i].fname + '</span>'
						/*$("<span/>").addClass("ndelem dirnode").attr({
						 'data-fname' : msg[i].fname,
						 'data-path' : dir_json.dname + '/' + msg[i].fname,
						 }).append(msg[i].fname);*/
						if (selectedItem != null) {
							$('#nodes').jqxTree('expandItem', selectedItem.element);
							$('#nodes').jqxTree('addTo', {
								html : nodeHtml//'<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path="' + dir_json.dname + '"/"' + msg[i].fname + '">' + msg[i].fname + '</span>'
							}, selectedItem.element);

						} else {
							var treeItems = $("#nodes").jqxTree('getItems');
							var firstItem = treeItems[0];
							var firstItemElement = firstItem.element;
							$('#nodes').jqxTree('addTo', {
								html : nodeHtml//'<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dir_json.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span>'
							}, firstItemElement);
						}

						//$('<li><span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dir_json.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span></li>').appendTo($list).draggable({revert: true, containment: "#nodes"}).droppable({accept : 'div.4'});
					}

					filelist(msg[i].fname, msg[i].size, msg[i].isdir);

				}
			}

		}

		function initFileObject($li, dsbl) {
			$li.draggable({
				revertDuration : 10,
				revert : true, // grouped items animate separately, so leave this number low
				start : function(e, ui) {
					ui.helper.addClass(selectedClass);
				},
				stop : function(e, ui) {
					// reset group positions
					$(this).parent().children('li.selected').css({
						top : 0,
						left : 0
					});
				},
				drag : function(e, ui) {
					// set selected group position to main dragged object
					// this works because the position is relative to the starting position
					$(this).parent().children('li.selected').css({
						top : ui.position.top,
						left : ui.position.left
					});
				}
			}).droppable({
				'disable' : dsbl,
				accept : '.file-div',
				greedy : true,
				drop : function() {
					//alert('hi this');
					if ($(this).data('dir')) {
						var obj = {
							data : {
								list : $(this).parent().children('li.selected'),
								file : $(this),
								pasteSpl : true,
							}
						}

						cut(obj);
						paste(obj);

						$(this).parent().children('li.selected').remove();
					}
				}
			});
		}

		function filelist(fname, size, isdir) {
			var src = isdir == 'true' ? 'css/images/folder.png' : 'css/images/mimes/undefined.png';
			var dsbl = (isdir == 'true') ? false : true;
			var $item = $("<li></li>").attr({
				'title' : fname,
				'data-fname' : fname,
				'data-path' : dir_json.dname + '/' + fname,
				'data-dir' : isdir,
				'data-fsize' : size
			}).addClass("file-div").append("<div class='fsdiv' ><img class='fselem' src='" + src + "' height=40px width=40px ><br/><span class='fname fselem' >" + fname + "</span></div>");
			initFileObject($item);
			$('#file-list').append($item, dsbl);
		}

		/* File upload process with drag and Drop, web worker and web socket
		 * TODO: it should check
		 */
		/*		function handleFileSelect(ev) {
		 $(this).children('ul').removeClass('droper');
		 $('#uploadwindow').jqxWindow('show');
		 ev.stopPropagation();
		 ev.preventDefault();
		 var files = ev.target.files || ev.dataTransfer.files;
		 // FileList object.
		 worker.port.postMessage({
		 'mesgtype' : 'file_list',
		 'files' : files,
		 'dname' : dir_json.dname,
		 clientid : clientid,
		 });
		 // files is a FileList of File objects. List some properties.
		 for (var i = 0, f; f = files[i]; i++) {
		 //alert(f.webkitRelativePath);

		 /*worker.port.postMessage({
		 'file' : f,
		 'dname' : dir_json.dname
		 });*
		 $('#uploadwindow').jqxWindow('bringToFront');
		 $('#upload_status').append('<div class="upload_file">' + f.name + '<span class="cancel uc" data-fname="' + f.name + '">Cancel</span></div>');
		 filelist(f.name, f.size, false);
		 }
		 }
		 */
		function handleFileSelect(ev) {
			ev.stopPropagation();
			ev.preventDefault();

			if (ev.dataTransfer) {
				var length = ev.dataTransfer.items.length || ev.target.files.length;
				var src, isdir, septr, path_ext = [], q = 0;
				for (var i = 0, f; i < length; i++) {
					var entry = ev.dataTransfer.items[i].webkitGetAsEntry();

					if (entry.isFile) {
						isdir = 'false';
					} else {
						isdir = 'true';
					}
					filelist(entry.name, entry.size, isdir);
					traverseFileTree(entry)
				}
			}
		}

		function traverseFileTree(item, path) {
			path = path || "/";
			if (item.name.indexOf('.') != 0) {
				if (item.isFile) {
					// Get file
					item.file(function(file) {

						worker.port.postMessage({
							'mesgtype' : 'file_list',
							'files' : file,
							'dname' : dir_json.dname + path + file.name,
							clientid : clientid,
						});
						$('#upload_status').append('<div class="upload_file">' + file.name + '<span class="cancel uc" data-fname="' + file.name + '">Cancel</span></div>');
					});
					$('#uploadwindow').jqxWindow('show');
					$('#uploadwindow').jqxWindow('bringToFront');
				} else if (item.isDirectory) {
					// Get folder contents

					var guid = createUUID();
					var add_obj = {
						clientid : clientid,
						mesgtype : "request",
						service : "fmgr",
						request : 'create_dir',
						cookie : guid,
						source : dir_json.dname,
					}
					var spath = item.fullPath;
					var sep = spath.lastIndexOf('/');
					var source_ext = spath.substring(0, sep);
					add_obj.source = dir_json.dname + source_ext;
					add_obj.srcargs = [spath.substring(sep + 1, spath.length)];

					wssend(add_obj);

					maptable[add_obj.cookie] = 'question';

					var dirReader = item.createReader();
					dirReader.readEntries(function(entries) {
						for (var i = 0; i < entries.length; i++) {
							traverseFileTree(entries[i], path + item.name + "/");
						}
					});

				}
			}
		}


		$('.upload_file, .download_file').live('hover', function() {
			$(this).children().toggleClass('cancel');
		});

		$('.uc').live('click', function(e) {
			var fname = $(this).data('fname');
			$(this).parent().remove();
			if ($('#upload_status div').length == 0)
				$('#uploadwindow').jqxWindow('hide');

			worker.port.postMessage({
				'mesgtype' : 'cancel',
				'fname' : fname,
				'dname' : dir_json.dname,
				clientid : clientid,
			});
		});

		function handleDragOver(e) {
			e.stopPropagation();
			e.preventDefault();
			e.dataTransfer.dropEffect = 'copy';
			// Explicitly show this is a copy.
		}

		function refresh() {
			$('#nodes').find('span[data-path="' + dir_json.dname + '"]').click();
		}

		function info(e) {
			var f = e.data.file;
			var fname = f.data("path");
			var s = f.data('fsize');
			var dfname = fname.substring(fname.lastIndexOf('/') + 1, fname.length);
			var typeinfo = (fname.lastIndexOf('.') > 0) ? fname.substring(fname.lastIndexOf('.') + 1, fname.length) : 'unknown';
			var finfo = f.data('dir') ? 'Type : <b>Folder</b>' : 'Type :  <b>' + typeinfo + ' Document</b><br>Size :  <b>' + s + ' Bytes</b>';
			var data = '<img src="css/images/file-info.png" height=32 width=32 align=left />Name : <b>' + dfname + '</b><br>' + finfo;
			$('<div/>').append('<div/>').append('<div/>').attr('id', 'infownd').jqxWindow({
				resizable : false,
				draggable : false,
				title : 'Info',
				content : data,
				isModal : true,
				closeButtonAction : 'close',
				width : 300,
				height : 100,
			});
		}

		function openfn(e) {
			if (e.data) {
				var file = e.data.file;
				var path = file.data('path');
				if (file.data('dir')) {
					$('#nodes').find('span[data-path="' + path + '"]').click();
				}
			}
		}

		/*function f_rename(e, item) {
		 $(".rename").live('keypress', function(e) {
		 if (e.which == 13) {
		 $(this).removeClass('rename').attr('contenteditable', 'false');
		 };
		 });
		 console.log(item);
		 item.find('span').addClass('rename').attr('contenteditable', 'true').focus();
		 }*/

		/*
		 ************************************************************************************************************************************
		 *
		 *  											Filemanager UI Binding Controls.
		 *
		 * **********************************************************************************************************************************
		 */

		$('#nodes span.dirnode').live('click', function() {
			$node_li = $(this)
			var selectedItem = $('#nodes').jqxTree('selectedItem');

			$node_li.parent().next("ul").remove();
			//$node_li.parent().parents('ul').show();
			/*if ($node_li.hasClass("tree_expand")) {
			 expander = true;
			 $node_li.removeClass("tree_expand").next('ul').slideUp('slow');
			 } else {
			 expander = false;
			 $('li.node_active').removeClass('node_active');
			 $node_li.next('ul').remove().end().parent('li').addClass('node_active').end().addClass('tree_expand has_tree');
			 }*/
			sendreq($node_li);
		});
		jQuery.event.props.push('dataTransfer');
		//setting the property data transfer
		// Setup the dnd listeners.
		var dropZone = $('#dropzone');
		dropZone.bind('dragover', handleDragOver);
		dropZone.bind('drop', handleFileSelect);
		$('#inputmode').bind('change', handleFileSelect);
		/*
		 * Menubar Items functionality
		 */

		$('#add_fl').click(newfile);
		//$("#create_file").click(newfile);

		$('#upload_fl').click(function() {
			$('#inputmode').removeAttr('webkitdirectory').attr('multiple', true).click();
		});
		$('#upload_fldr').click(function() {
			$('#inputmode').removeAttr('multiple').attr('webkitdirectory', true).click();
		});

		$('#nodes').hide();

		$('#gettree').click(function() {
			$('#nodes').fadeToggle();

		});

		$('#file-list').sortable().cnxtmenu({
			'menuid' : '#cmenu',
			items : {
				create_file : newfile,
				create_folder : newfolder,
				paste : paste,
			}

		});

		/*$('#dropzone').cnxtmenu({
		 'menuid' : '#cmenu',
		 paste : paste,
		 create_file : create_file,
		 create_folder : create_folder
		 })
		 */
		$('li.file-div').live('click', function(e) {

			e.ctrlKey ? $(this).toggleClass('selected') : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');

			var fname = $(this).data('fname');
			var typeinfo = (fname.lastIndexOf('.') > 0) ? fname.substring(fname.lastIndexOf('.') + 1, fname.length) : 'unknown';
			var size = $(this).data('fsize');
			var finfo = $(this).data('dir') ? 'Folder' : typeinfo + ' Document' + "&nbsp;&nbsp;&nbsp;" + size + ' Bytes';

		}).live('dblclick', function(e) {
			var $file_li = $(this);
			if ($file_li.attr('data-dir') == 'true') {
				$('#nodes').find('span[data-path="' + $file_li.data("path") + '"]').click();
				//sendreq($file_li);
			} else {
				openfn(e);
			}
		}).cnxtmenu({
			'menuid' : '#cmenu',
			items : //['open','download','copy','cut','paste','dlt','info'],
			{
				open : openfn,
				download : handleFileWriter,
				info : info,
				dlt : remove,
				copy : copy,
				cut : cut,
				paste : paste,
				newfile : newfile,
				newfolder : newfolder,
				newwnd : openNewWindow
			}
		});
		function parent() {
			var parent = dir_json.dname.substring(0, dir_json.dname.lastIndexOf('/'));
			if (parent != '')
				$('#nodes').find('span[data-path="' + parent + '"]').click();

		}

		function copy(e) {
			var list = e.data.list;
			var args = [];
			copyOrCutElemetns = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
				copyOrCutElements.push($(this));
			});
			localStorage.clear();
			localStorage.setItem('clipboard', JSON.stringify({
				'request' : 'copy',
				'srcargs' : args,
				'source' : dir_json.dname
			}));
		}

		function cut(e) {
			var list = e.data.list;

			var args = [];
			copyOrCutElemetns = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
				copyOrCutElements.push($(this));
			});
			localStorage.clear();
			localStorage.setItem('clipboard', JSON.stringify({
				'request' : 'move',
				'srcargs' : args,
				'source' : dir_json.dname
			}));
			list.fadeOut();
		}

		var FODialog = $('<div id="circular3dG"><div id="circular3d_1G" class="circular3dG"></div><div id="circular3d_2G" class="circular3dG"></div><div id="circular3d_3G" class="circular3dG"></div><div id="circular3d_4G" class="circular3dG"></div><div id="circular3d_5G" class="circular3dG"></div><div id="circular3d_6G" class="circular3dG"></div><div id="circular3d_7G" class="circular3dG"></div><div id="circular3d_8G" class="circular3dG"></div></div>');

		function paste(e) {
			var list = e.data.list;
			var destination_folder = e.data.file;
			var pasteInOut = e.data.pasteSpl;
			var clipboard_obj = JSON.parse(localStorage.getItem('clipboard'));

			var destination;
			if (pasteInOut) {
				var dest = destination_folder.data("path");
				destination = dest;
			} else {
				destination = dir_json.dname;
				$.each(copyOrCutElements, function(v, item) {
					var fileItem = $(item).data('fname');
					var isdir = $(item).data('dir').toString();
					filelist(fileItem, 4096, isdir);
				})
			}
			copyOrCutElements = [];
			//var destination = dest ? dest :  dir_json.dname;
			var guid = createUUID();
			var paste_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : clipboard_obj.request, //move||copy||remove||create_file||create_dir
				cookie : guid,
				source : clipboard_obj.source,
				destination : destination,
				srcargs : clipboard_obj.srcargs
			}

			wssend(paste_obj);

			maptable[paste_obj.cookie] = 'question';

			FODialog.dialog({
				resizable : false,
				title : 'File Operation',
				closeOnEscape : false,
				open : function(event, ui) {
					$(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
				},
				height : 140,
				modal : true,
			});

		}

		function newfile(ev) {
			var guid = createUUID();
			var add_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : 'create_file', //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dir_json.dname,
				//destination:
				srcargs : 'arg'
			}

			//
			$('<div/>').addClass('dialogClass').append('<p><span style="float:left; margin:0 7px 20px 0;"> </span>Enter The File Name:<input type="text" id="flname"></p>').dialog({
				resizable : false,
				title : 'Prompt',
				//dialogClass: "dialogClass",
				height : 170,
				modal : true,
				buttons : {
					"Create" : function() {
						if ($('input#flname').val() != '') {
							add_obj.srcargs = [$('input#flname').val()];
							wssend(add_obj);

							maptable[add_obj.cookie] = 'question';
							filelist($('input#flname').val(), 0, false);

							$(this).dialog("close").remove();
						}
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});

		}

		/*
		 * FIXME:button fix jquery ui
		 */

		$('.ui-button-text').each(function(i) {
			$(this).html($(this).parent().attr('text'))
		})

		$('#add_fldr').click(newfolder);
		//$('#create_folder').click(newfolder);
		function newfolder(ev) {
			var guid = createUUID();
			var add_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : 'create_dir', //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dir_json.dname,
				//destination:
				//srcargs : clipboard_obj.srcargs
			}
			$('<div/>').addClass('dialogClass').append("<p><span style='float:left; margin:0 7px 20px 0;'> </span>Enter The Folder Name:<input type='text' id='flname'></p>").dialog({
				resizable : false,
				title : 'Prompt',
				height : 170,
				modal : true,
				buttons : {
					"Create" : function() {
						if ($('input#flname').val() != '') {
							add_obj.srcargs = [$('input#flname').val()];

							wssend(add_obj);

							maptable[add_obj.cookie] = 'question';
							filelist($('input#flname').val(), 4096, 'true')
							$(this).dialog("close").remove();
						}
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});
		}

		function remove(e) {
			var list = e.data.list;
			var args = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
			});

			var guid = createUUID();
			var dlt_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : "remove", //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dir_json.dname,
				//destination:
				srcargs : args
			}

			$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>These items will be permanently deleted and cannot be recovered. Are you sure?</p>').dialog({
				resizable : false,
				height : 140,
				modal : true,
				buttons : {
					"Delete all items" : function() {
						wssend(dlt_obj);
						maptable[dlt_obj.cookie] = 'remove';
						list.remove();
						$(this).dialog("close").remove();
						//refresh();
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});

			console.log(dir_json.dname);
		}


		$(window).unload(function() {
			if (logoutcall) {
				logoutuser(loginuserid);
			}
			ws.close();
		})
		$('body').bind({
			'unload' : function() {

				worker.terminate();
				Dworker.terminate();
				localStorage.clear();
				window.requestFileSystem = window.requestFileSystem || window.webkitRequestFileSystem;
				var fs = null;

				window.requestFileSystem(window.TEMPORARY, 1024 * 1024, function(filesystem) {
					fs = filesystem;
				}, errorHandler);

				var dirReader = fs.root.createReader();
				dirReader.readEntries(function(entries) {
					for (var i = 0, entry; entry = entries[i]; ++i) {
						if (entry.isDirectory) {
							entry.removeRecursively(function() {
							}, errorHandler);
						} else {
							entry.remove(function() {
							}, errorHandler);
						}
					}
				});

			}
		});
		$(document).bind({
			'contextmenu' : function() {
				return false;
			},
			'click' : function() {
				$(".akp").hide();
			}
		})

		$("#refresh").click(refresh);
		$("#home_folder").click(function() {
			$('#home').click();
		});
		$("#parent").click(parent);

		/*
		 * Search For fmgr
		 *
		 */

		var search_id;
		$("#fmgrSearchBox").bind('keyup', function(e) {
			e.stopPropagation();
			var str = $(this).val();

			var obj = {
				service : "fmgr",
				clientid : clientid,
				cookie : search_id,
				mesgtype : "request",
				request : "cancel"
			}
			wssend(obj);
			if (str) {
				fmgrSearchReq(str);
				$(".searchResults").empty().append("Searching..");

				if (e.which == 13) {
					$(this).select();
				}
			} else {
				$(".searchResults").empty().append("Searching..");
			}
		});
		/*.on('keydown', function(e) {
		 if (e.keyCode == 8)
		 $("#fmgrSearchBox").trigger('keypress');
		 });*/

		$("#fmgrSearchBtn").bind('click', function(e) {
			e.stopPropagation();
			var string = $("#fmgrSearchBox").val();
			if (string) {
				fmgrSearchReq(string);
				$(".searchResults").empty();
			}
		})
		function fmgrSearchReq(str) {
			var unique = createUUID();
			var obj = {
				clientid : clientid,
				service : "fmgr",
				mesgtype : "request",
				request : "search",
				cookie : unique,
				dname : dir_json.dname,
				key : str,

			}
			wssend(obj);
			search_id = obj.cookie;
			maptable[obj.cookie] = 'search';
		}

		function handleFmgrSearchResults(resp) {

			/*if (!$("#fmgrSearchResults").length) {

			 var title = $("<div/>").append("Vault Search Results");
			 var list = $("<div/>").attr("id", "fmgrSearchFilesList");
			 var content = $("<div/>").append(list);
			 $("<div/>").attr('id', "fmgrSearchResults").append(title).append(content).jqxWindow({
			 width : "400px",
			 height : "300px",
			 })
			 } else {
			 $("#fmgrSearchResults").jqxWindow('show');

			 }

			 $('#fmgrSearchFilesList').append("<li>Please Wait Loading...</li>");*/

			if (!$(".searchResults").is(":visible")) {
				$(".searchResults").show();
			}

			var path = resp.isdir == "true" ? resp.fpath + "/" + resp.fname : resp.fpath;

			var src = resp.isdir == "true" ? 'css/images/folder.png' : 'css/images/mimes/undefined.png';

			var item = $("<div/>").attr({
				"data-path" : path,
				title : resp.fname
			}).addClass("resultItem").appendTo(".searchResults").append("<img src='" + src + "' height=32 width=32 />").append("<span>" + resp.fname + "</span>").bind('click', function(e) {
				e.stopPropagation();
				var path = $(this).data("path");
				openNewWindow(path)
			});

			//console.log(resp);

		}

		/*
		 * **********************************************************************************************************************************
		 *
		 *                                                      File manager window
		 * Date:25/10/12
		 * **********************************************************************************************************************************
		 */

		function openNewWindow(e) {
			var path;
			if (e.data) {
				path = e.data.file.data("path");
			} else {
				path = e;
			}

			window_manager.getNewWindow(path);
		}

		var window_manager = {
			_counter : 0,
			windows : [],
			mapRequest : {},
			requestType : {},
			getCounter : function() {
				return ++window_manager._counter;
			},

			getNewWindow : function(path) {
				var w = new fmgrWindow(window_manager.getCounter(), path);
				window_manager.windows.push(w);
				return w;
			},

			getWindowById : function(id) {
				for (var i = 0; i < window_manager.windows.length; i++) {
					var current = window_manager.windows[i];
					if (current.id == id) {
						return current;
					}
				}
				return null;
			},
			sendRequest : function(win_ref) {
				// Either accept a parameter that is a reference to a acpwindow or the index for which window in window_manager.windows

			}
		};

		function fmgrWindow(id, path) {
			this.id = id;
			this.akpwindow = $("<div/>");
			this.dname = path;
			this.init = function() {
				//var closebtn = $("<span class='closeIcon'></span>").bind("click", this.distroy);

				var refreshbutton = $("<div/>").addClass("ui-menu_item").attr('title', 'refresh').append('<span class="ui-image-icon refresh"></span>').bind('click', {
					wnd : this
				}, this.commands.refresh);

				var upbutton = $("<div/>").addClass("ui-menu_item").attr('title', 'up').append('<span class="ui-image-icon parent"></span>').bind('click', {
					wnd : this
				}, this.commands.parentDirectory);

				var newfile = $("<div/>").addClass("ui-menu_item").attr('title', 'create New file').append('<span class="ui-image-icon add_fl"></span>').bind('click', {
					wnd : this
				}, this.commands.createNewFile);

				var newfldr = $("<div/>").addClass("ui-menu_item").attr('title', 'create New folder').append('<span class="ui-image-icon add_fldr"></span>').bind('click', {
					wnd : this
				}, this.commands.createNewFolder);

				var toolbar = $("<div/>").append(newfile).append(newfldr).append(upbutton).append(refreshbutton).addClass("wndtoolbar");
				//.append(closebtn);

				var prev = $("<div/>").addClass("prv").append("P").bind('click', scrollPath);
				var next = $("<div/>").addClass("nxt").append("N").bind('click', scrollPath);
				var dirtray = $("<ul/>").addClass("pathdirs");
				var path = $("<div/>").append(prev).append(dirtray).append(next).addClass("wndpath");

				var viewport = $("<div/>").addClass("wndview").append("<ul/>");
				this.akpwindow.append(toolbar).append(path).append(viewport).addClass("window_view");

				$("<div/>").append("<div>Vault</div>").append(this.akpwindow).attr('id', this.id).jqxWindow({
					closeButtonAction : 'close',
					height : 400,
					width : 600,
				});

				var uuid = createUUID();
				var obj = {
					clientid : clientid,
					mesgtype : "request",
					service : "fmgr",
					request : "getdir",
					cookie : uuid,
					dname : this.dname
				}
				this.sendRequest(obj, "viewport");

			};
			this.init();
		}

		function scrollPath(e) {
			var dirtn;
			btn = $(this).hasClass('nxt') ? dirtn = '+' : dirtn = '-';
			$(this).closest('.wndpath').find('.pathdirs').stop().animate({
				scrollLeft : dirtn + '=200'
			}, 1000);
		}


		fmgrWindow.prototype.updateHandle = function(response) {
			switch(window_manager.requestType[response.cookie]) {
				case "viewport":
					this.viewChange(response.direlements)
					break;
				case "new_file":
					this.commands.refresh(this);
					break;
				case "new_folder":
					this.commands.refresh(this);
					break;
				case "delete":
					this.commands.refresh(this);
					break;
				case "paste":
					if (!response.status) {
						handleQuestion(response, this);
					} else {
						if (response.status != "fail") {
							this.commands.refresh();
						}

					}

					break;
				default:
					console.log("unknown Response");
			}

		}
		function handleQuestion(response, wnd) {

			var button = $('<input type="checkbox" id="check" /><label for="check">Apply this answer for all</label>');
			$('#check').button();

			var q_obj = {
				clientid : clientid,
				mesgtype : "answer",
				service : "fmgr",
				cookie : svr_cmds.cookie,
				//answer://yes/no/yesall/noall
			};

			$('<div/>').append('<p>' + response.estring + '</p><br/>').append(button).addClass('ui-state-highlight').dialog({
				resizable : false,
				height : 'auto',
				modal : true,
				position : ['right', "bottom"],
				closeOnEscape : false,
				open : function(event, ui) {
					$(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
				},
				buttons : {
					"Yes" : function() {

						if (!$('#check').is(':checked'))
							q_obj.answer = 'yes';
						else
							q_obj.answer = 'yesall'

						wnd.sendRequest(q_obj, "paste");
						//wssend(q_obj);

						$(this).dialog("close").remove();
					},
					'No' : function() {

						if (!$('#check').is(':checked'))
							q_obj.answer = 'no';
						else
							q_obj.answer = 'noall'
						//wssend(q_obj);

						wnd.sendRequest(q_obj, "paste");

						$(this).dialog("close").remove();

					}
				}
			});

		}


		fmgrWindow.prototype.showPath = function(path) {
			this.akpwindow.children(".wndpath").children("ul.pathdirs").empty();
			var paths = path.split("/");
			var tmp = "";
			var flag = false;
			var pathname, dir;
			var wnd = this;

			for (var i = 0; i < paths.length; i++) {
				if (paths[i]) {
					tmp += "/" + paths[i];
					if (tmp == activedir) {
						flag = true;
					}
					if (flag) {
						if (tmp == activedir) {
							pathname = "Home";
						} else {
							pathname = paths[i];
						}

						dir = $("<li/>").append(pathname).attr('data-dname', tmp).bind('click', function(e) {
							wnd.emptyViewPort();
							var uuid = createUUID();
							var obj = {
								clientid : clientid,
								mesgtype : "request",
								service : "fmgr",
								request : "getdir",
								cookie : uuid,
								dname : $(this).data("dname")
							}
							wnd.sendRequest(obj, "viewport");
						});
						this.akpwindow.children(".wndpath").children("ul.pathdirs").append(dir).stop().animate({
							scrollLeft : '100%'
						}, 1000);
					}

				}
			}

		}

		fmgrWindow.prototype.commands = function() {

		}

		fmgrWindow.prototype.commands.open = function(e) {
			var file = e.data.file;
			var wnd = e.data.wnd;
			if (file.attr('data-dir') == 'true') {
				var uuid = createUUID();
				var obj = {
					clientid : clientid,
					mesgtype : "request",
					service : "fmgr",
					request : "getdir",
					cookie : uuid,
					dname : file.data("path"),
				}
				wnd.sendRequest(obj, "viewport");
				file.parent().empty();
			}
		}
		fmgrWindow.prototype.commands.cut = function(e) {

			var list = e.data.list;
			var wnd = e.data.wnd;

			var args = [];
			copyOrCutElemetns = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
				copyOrCutElements.push($(this));
			});

			fmgrClipboard = {
				'request' : 'move',
				'srcargs' : args,
				'source' : wnd.dname
			};
			list.fadeOut();

		}
		fmgrWindow.prototype.commands.copy = function(e) {
			var list = e.data.list;
			var wnd = e.data.wnd;
			var args = [];
			copyOrCutElemetns = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
				copyOrCutElements.push($(this));
			});
			fmgrClipboard = {
				'request' : 'copy',
				'srcargs' : args,
				'source' : wnd.dname
			};

		}
		fmgrWindow.prototype.commands.paste = function(e) {
			var wnd = e.data.wnd;
			var list = e.data.list;
			var destination_folder = e.data.file;
			var pasteInOut = e.data.pasteSpl;
			var clipboard_obj = fmgrClipboard;

			var destination;
			if (pasteInOut) {
				var dest = destination_folder.data("path");
				destination = dest;
			} else {
				destination = dir_json.dname;
				/*$.each(copyOrCutElements, function(v, item) {
				 var fileItem = $(item).data('fname');
				 var isdir = $(item).data('dir').toString();
				 filelist(fileItem, 4096, isdir);
				 })*/
			}
			copyOrCutElements = [];
			//var destination = dest ? dest :  dir_json.dname;
			var guid = createUUID();
			var paste_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : clipboard_obj.request, //move||copy||remove||create_file||create_dir
				cookie : guid,
				source : clipboard_obj.source,
				destination : destination,
				srcargs : clipboard_obj.srcargs
			}

			wnd.sendRequest(paste_obj, "paste");
			if (clipboard_obj.request == "move") {
				fmgrClipboard = null;
			}

		}
		fmgrWindow.prototype.commands.deletefile = function(e) {
			var list = e.data.list;
			var wnd = e.data.wnd;
			var args = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
			});

			var guid = createUUID();
			var dlt_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : "remove", //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : wnd.dname,
				//destination:
				srcargs : args
			}

			$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>These items will be permanently deleted and cannot be recovered. Are you sure?</p>').dialog({
				resizable : false,
				height : 140,
				modal : true,
				buttons : {
					"Delete all items" : function() {
						wnd.sendRequest(dlt_obj, "delete");

						list.remove();
						$(this).dialog("close").remove();
						//refresh();
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});

		}
		fmgrWindow.prototype.commands.download = function() {

		}

		fmgrWindow.prototype.commands.createNewFile = function(e) {
			var wnd = e.data.wnd;

			var guid = createUUID();
			var add_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : 'create_file', //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : wnd.dname,
				srcargs : 'arg'
			}

			//
			$('<div/>').addClass('dialogClass').append('<p><span style="float:left; margin:0 7px 20px 0;"> </span>Enter The File Name:<input type="text" id="flname"></p>').dialog({
				resizable : false,
				title : 'Prompt',
				height : 170,
				modal : true,
				buttons : {
					"Create" : function() {
						if ($('input#flname').val() != '') {
							add_obj.srcargs = [$('input#flname').val()];
							wnd.sendRequest(add_obj, "new_file");

							//filelist($('input#flname').val(), 0, false);

							$(this).dialog("close").remove();
						}
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});

		}
		fmgrWindow.prototype.commands.createNewFolder = function(e) {
			var wnd = e.data.wnd;
			var guid = createUUID();
			var add_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : 'create_dir', //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : wnd.dname,
				//destination:
				//srcargs : clipboard_obj.srcargs
			}
			$('<div/>').addClass('dialogClass').append("<p><span style='float:left; margin:0 7px 20px 0;'> </span>Enter The Folder Name:<input type='text' id='flname'></p>").dialog({
				resizable : false,
				title : 'Prompt',
				height : 170,
				modal : true,
				buttons : {
					"Create" : function() {
						if ($('input#flname').val() != '') {
							add_obj.srcargs = [$('input#flname').val()];

							wnd.sendRequest(add_obj, "new_folder");

							//filelist($('input#flname').val(), 4096, 'true')
							$(this).dialog("close").remove();
						}
					},
					Cancel : function() {
						$(this).dialog("close").remove();
					}
				}
			});

		}

		fmgrWindow.prototype.commands.parentDirectory = function(e) {

			var wnd = e.data.wnd;
			var path = e.data.wnd.dname;
			if (path != activedir || path != ghomedir) {

				var parent = path.substring(0, path.lastIndexOf('/'));

				var uuid = createUUID();
				var obj = {
					clientid : clientid,
					mesgtype : "request",
					service : "fmgr",
					request : "getdir",
					cookie : uuid,
					dname : parent
				}
				wnd.emptyViewPort();
				wnd.sendRequest(obj, "viewport");
			}

			//console.log(path);
		}

		fmgrWindow.prototype.commands.refresh = function(e) {
			var wnd, path;
			if (e.data) {
				wnd = e.data.wnd;
				path = e.data.wnd.dname;
			} else {
				wnd = e;
				path = e.dname;
			}

			var uuid = createUUID();
			var obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "fmgr",
				request : "getdir",
				cookie : uuid,
				dname : path

			}
			wnd.emptyViewPort();
			wnd.sendRequest(obj, "viewport");

			//console.log(path);
		}

		fmgrWindow.prototype.viewChange = function(elements) {
			var filelist = this.akpwindow.children(".wndview").children("ul")
			//filelist.empty();
			for (var i = 0; i < elements.length; i++) {

				var $item = this.fileitem(elements[i].fname, elements[i].size, elements[i].isdir);

				filelist.append($item);

			}

		}
		/*$(".filediv").cnxtmenu({
		 'menuid' : '#cmenu',
		 items : //['open','download','copy','cut','paste','dlt','info'],
		 {
		 open : openfn,
		 download : handleFileWriter,
		 info : info,
		 dlt : remove,
		 copy : copy,
		 cut : cut,
		 paste : paste,
		 newfile : newfile,
		 newfolder : newfolder,
		 newwnd : openNewWindow
		 }
		 });*/
		fmgrWindow.prototype.emptyViewPort = function() {
			this.akpwindow.children(".wndview").children('ul').empty();
		}

		fmgrWindow.prototype.fileitemBindEvents = function(item, fname) {
			var wnd = this;
			var dsbl = item.data('dir') ? false : true;
			item.click(function(e) {
				e.ctrlKey ? $(this).toggleClass('selected') : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');
			}).dblclick(function(e) {
				if ($(this).attr('data-dir') == 'true') {
					var uuid = createUUID();
					var obj = {
						clientid : clientid,
						mesgtype : "request",
						service : "fmgr",
						request : "getdir",
						cookie : uuid,
						dname : wnd.dname + '/' + fname,
					}
					wnd.sendRequest(obj, "viewport");
					$(this).parent().empty();
				}
			}).draggable({

				appendTo : "body",
				helper : 'clone',
				zindex : 1000000,
				revertDuration : 10,
				revert : true, // grouped items animate separately, so leave this number low
				start : function(e, ui) {
					ui.helper.addClass(selectedClass);
				},
				stop : function(e, ui) {
					// reset group positions
					$(this).parent().children('li.' + selectedClass).css({
						top : 0,
						left : 0
					});
				},
				drag : function(e, ui) {
					$(this).parent().children('li.' + selectedClass).css({
						top : ui.position.top,
						left : ui.position.left
					});
				}
			}).droppable({
				'disable' : dsbl,
				accept : '.filediv',
				greedy : true,
				drop : function() {
					//alert('hi this');
					if ($(this).data('dir')) {
						var obj = {
							data : {
								wnd : wnd,
								list : $(this).parent().children('li.selected'),
								file : $(this),
								pasteSpl : true,
							}
						}

						wnd.commands.cut(obj);
						wnd.commands.paste(obj);

						$(this).parent().children('li.' + selectedClass).remove();
					}
				}
			}).contextmenu(function(e) {
				e.preventDefault();
				e.stopPropagation();

				e.ctrlKey ? $(this).addClass('selected') : ($(this).hasClass('selected')) ? '' : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');
				var list = $(this).parent().children('.selected');
				var arguements = {
					current : this,
					file : $(this),
					list : list,
					pasteSpl : true,
					wnd : wnd
				};

				$("#cmenu").css({
					top : e.pageY + 'px',
					left : e.pageX + 'px'
				}).show().children('li').hide().unbind('click').end().children("#open").bind('click', arguements, wnd.commands.open).show().end().children("#download").bind('click', arguements, handleFileWriter).show().end().children("#info").bind('click', arguements, info).show().end().children("#dlt").bind('click', arguements, wnd.commands.deletefile).show().end().children("#cut").bind('click', arguements, wnd.commands.cut).show().end().children("#copy").bind('click', arguements, wnd.commands.copy).show().end().children("#paste").bind('click', arguements, wnd.commands.paste).show().end().children("#newfile").bind('click', arguements, wnd.commands.createNewFile).show().end().children("#newfolder").bind('click', arguements, wnd.commands.createNewFolder).show().end().children("#newwnd").bind('click', arguements, openNewWindow).show().end();

				$(this).data('dir') ? $("#cmenu").children('.fldremove').hide() : $("#cmenu").children('#paste,#open,#newwnd').hide();

			})
		}

		fmgrWindow.prototype.fileitem = function(fname, size, isdir) {
			var wnd = this;
			var src = isdir == 'true' ? 'css/images/folder.png' : 'css/images/mimes/undefined.png';
			var dsbl = (isdir == 'true') ? false : true;
			var $item = $("<li></li>").attr({
				'title' : fname,
				'data-fname' : fname,
				'data-path' : this.dname + '/' + fname,
				'data-dir' : isdir,
				'data-fsize' : size
			}).addClass("filediv").append("<div class='fsdiv' ><img class='fselem' src='" + src + "' height=40px width=40px ><br/><span class='fname fselem' >" + fname + "</span></div>");
			this.fileitemBindEvents($item, fname);
			return $item;

		}
		fmgrWindow.prototype.distroy = function(e) {
			$(this).parent().parent().remove();

			//e.data.wnd.remove();
		}

		fmgrWindow.prototype.sendRequest = function(obj, reqtype) {
			if (reqtype == "viewport") {
				this.dname = obj.dname;
				this.showPath(this.dname);
			}
			wssend(obj);
			maptable[obj.cookie] = "window";
			window_manager.mapRequest[obj.cookie] = this.id;
			window_manager.requestType[obj.cookie] = reqtype;
		}
		/*
		 * ***********************************************************************************************************************************
		 *
		 * 															JQX WIDGETS
		 *
		 *************************************************************************************************************************************
		 */

		$('#uploadwindow').jqxWindow({
			autoOpen : false,
			showCloseButton : false,
			showCollapseButton : true,
			width : 'auto',
			height : 'auto'
		});
		$('#downloads').jqxWindow({
			autoOpen : false,
			showCloseButton : false,
			showCollapseButton : true,
			height : 300,
			width : 310
		});

		$('#nodes').jqxTree({
			theme : theme
		});
		var upr = $("#uprogress").percentageLoader({
			width : 100,
			height : 100,
			progress : 0,
			position : {
				x : 200,
				y : 400
			},
			animationType : 'slide'
		});
		var dpr = $("#progress").percentageLoader({
			width : 100,
			height : 100,
			progress : 0,
			position : {
				x : 200,
				y : 400
			},
			animationType : 'slide'
		});

		/*
		 * ############################################################################################################################################
		 * Dstore
		 * 13/8/2012
		 *
		 *                                                                  SERVICE: DSTORE
		 *
		 * ############################################################################################################################################
		 *
		 */

		var dstoreObj;

		var dstore_downloader = new SharedWorker('dstoredownloadworker.js');
		dstore_downloader.port.start();
		dstore_downloader.port.onerror = akorp.werror;
		dstore_downloader.port.onmessage = dstoreDownloadWorkerMessageHandler;

		var dstore_uploader = new SharedWorker('dstoreuploadworker.js');
		dstore_uploader.port.start();
		dstore_uploader.port.onerror = akorp.werror;
		dstore_uploader.port.onmessage = dstoreUploadWorkerMessageHandler;

		function handleDstoreMessage(msg_obj) {

			var svr_cmds = msg_obj;

			/*if (svr_cmds.mesgtype == 'ack') {
			 dstore_uploader.port.postMessage(svr_cmds);
			 } else*/

			if (svr_cmds.mesgtype == "error") {
				$('<div />').append("<p>" + svr_cmds.estring + "</p>").css({
					color : 'red'
				}).dialog({
					position : ['right', "bottom"],
					closeOnEscape : false,
					buttons : {
						'OK' : function() {
							$(this).dialog('close').remove();
						}
					},
					dialogClass : 'error',
				})
			} else {

				switch(maptable[svr_cmds.cookie]) {
					case 'download':
						var strdata = svr_cmds.data;
						svr_cmds.data = window.atob(strdata);
						dstore_downloader.port.postMessage({
							obj : svr_cmds
						});
						break;
					case 'upload':
						dstore_uploader.port.postMessage(svr_cmds);
						break;
					case 'tree':
						dstoreTree(svr_cmds.direlements, expander);
						break;
					case 'question':

						if (!svr_cmds.status) {
							var button = $('<input type="checkbox" id="check" /><label for="check">Apply this answer for all</label>');
							$('#check').button();

							var q_obj = {
								clientid : clientid,
								mesgtype : "answer",
								service : "fmgr",
								cookie : svr_cmds.cookie,
								//answer://yes/no/yesall/noall
							};

							$('<div/>').append('<p>' + svr_cmds.estring + '</p><br/>').append(button).addClass('ui-state-highlight').dialog({
								resizable : false,
								height : 'auto',
								modal : true,
								position : ['right', "bottom"],
								closeOnEscape : false,
								open : function(event, ui) {
									$(".ui-dialog-titlebar-close", ui.dialog || ui).hide();
								},
								buttons : {
									"Yes" : function() {

										if (!$('#check').is(':checked'))
											q_obj.answer = 'yes';
										else
											q_obj.answer = 'yesall'
										wssend(q_obj);
										maptable[q_obj.cookie] = 'question';
										$(this).dialog("close");
									},
									'No' : function() {

										if (!$('#check').is(':checked'))
											q_obj.answer = 'no';
										else
											q_obj.answer = 'noall'
										wssend(q_obj);
										maptable[q_obj.cookie] = 'question';

										$(this).dialog("close");

									}
								}
							});
						} else {
							if (svr_cmds.status != "fail") {
								//refresh();
							}
							FODialog.dialog('close');
							console.log(svr_cmds.status);
						}
						break;
					case 'remove':
						break;
				}

			}

		}

		function dstoreDownloadWorkerMessageHandler(e) {
			var down_data = e.data;
			if (!down_data.file) {
				console.log(down_data);
			} else if (down_data.file.mesgtype == 'ack' || down_data.file.mesgtype == 'request' || down_data.file.mesgtype == 'cancel') {
				wssend(down_data.file);
				maptable[down_data.file.cookie] = 'download';
				dpr.setProgress(down_data.percent)
			} else if (down_data.file.mesgtype == 'save') {
				dpr.setProgress(down_data.percent)
				var dfname = down_data.file.dfname.substring(down_data.file.dfname.lastIndexOf('/') + 1, down_data.file.dfname.length);
				saveAs(down_data.file.fl, dfname);
				$('#dloads').find('div:eq(0)').remove();
				if ($('#dloads div').length == 0) {
					$('#downloads').jqxWindow('hide');
				}
			}
		}

		function dstoreUploadWorkerMessageHandler(e) {
			var dat = e.data.obj;
			if (!e.data.obj) {
				console.log(e.data);
			} else if (dat.mesgtype == 'request' || dat.mesgtype == 'cancel') {
				var pcnt = e.data.prct;
				upr.setProgress(Math.round(pcnt) / 100);
				wssend(dat);
				maptable[dat.cookie] = 'upload';
			} else if (dat.mesgtype == 'complete') {

				$('#upload_status').find('div:eq(0)').remove();
				if ($('#upload_status div').length == 0)

					$('#uploadwindow').jqxWindow('hide');
			}
		}

		function dstoreTree(svr_msg, expndr) {
			var msg = svr_msg;
			//console.log(msg)
			var $trash = $('li.node_active');
			var $list = $("ul", $trash).length ? $("ul", $trash) : $("<ul/>").appendTo($trash);
			$list.hide();
			for (var i = 0; i < msg.length; i++) {
				if (msg[i].fname.indexOf('.') != 0) {
					if (msg[i].isdir == 'true' && !expndr) {
						var selectedItem = $('#dstore_nodes').jqxTree('selectedItem');
						if (selectedItem != null) {
							$('#dstore_nodes').jqxTree('expandItem', selectedItem.element);
							$('#dstore_nodes').jqxTree('addTo', {
								html : '<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dstoreObj.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span>'
							}, selectedItem.element);

						} else {
							var treeItems = $("#dstore_nodes").jqxTree('getItems');
							var firstItem = treeItems[0];
							var firstItemElement = firstItem.element;
							$('#dstore_nodes').jqxTree('addTo', {
								html : '<span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dstoreObj.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span>'
							}, firstItemElement);
						}

						//$('<li><span class="ndelem dirnode" id="' + msg[i].fname + '" data-fname=' + msg[i].fname + ' data-path=' + dir_json.dname + '/' + msg[i].fname + '>' + msg[i].fname + '</span></li>').appendTo($list).draggable({revert: true, containment: "#nodes"}).droppable({accept : 'div.4'});
					}

					dstoreFileList(msg[i].fname, msg[i].size, msg[i].isdir);

				}
			}

		}

		function dstoreFileList(fname, size, isdir) {
			var src = isdir == 'true' ? 'css/images/folder.png' : 'css/images/mimes/undefined.png';
			var dsbl = (isdir == 'true') ? false : true;

			var $item = $("<li></li>").attr({
				'data-fname' : fname,
				'data-path' : dstoreObj.dname + '/' + fname,
				'data-dir' : isdir,
				'data-fsize' : size
			}).addClass("dstore-file-div").append("<div class='fsdiv' ><img class='fselem' src='" + src + "' height=30px width=30px  align=center>&nbsp;&nbsp;&nbsp;<span class='fname fselem' >" + fname + "</span></div>");
			initFileObject($item);
			$('#dstore_file-list').append($item, dsbl);
		}

		function dstoreHandleFileSelect(ev) {
			ev.stopPropagation();
			ev.preventDefault();
			var length = ev.dataTransfer.items.length || ev.target.files.length;
			var src, isdir, septr, path_ext = [], q = 0;
			for (var i = 0, f; i < length; i++) {
				var entry = ev.dataTransfer.items[i].webkitGetAsEntry();

				if (entry.isFile) {
					isdir = 'false';
				} else {
					isdir = 'true';
				}
				dstoreFileList(entry.name, entry.size, isdir);
				dstoreTraverseFileTree(entry)
			}
		}

		function dstoreTraverseFileTree(item, path) {
			path = path || "/";
			if (item.name.indexOf('.') != 0) {
				if (item.isFile) {
					// Get file
					item.file(function(file) {

						dstore_uploader.port.postMessage({
							'mesgtype' : 'file_list',
							'files' : file,
							'dname' : dstoreObj.dname + path + file.name,
							clientid : clientid,
						});
						$('#upload_status').append('<div class="upload_file">' + file.name + '<span class="cancel uc" data-fname="' + file.name + '">Cancel</span></div>');
					});
					$('#uploadwindow').jqxWindow('show');
					$('#uploadwindow').jqxWindow('bringToFront');
				} else if (item.isDirectory) {
					// Get folder contents

					var guid = createUUID();
					var add_obj = {
						clientid : clientid,
						mesgtype : "request",
						service : "dstore",
						request : 'create_dir',
						cookie : guid,
						source : dstoreObj.dname,
					}
					var spath = item.fullPath;
					var sep = spath.lastIndexOf('/');
					var source_ext = spath.substring(0, sep);
					add_obj.source = dstoreObj.dname + source_ext;
					add_obj.srcargs = [spath.substring(sep + 1, spath.length)];

					wssend(add_obj);
					maptable[add_obj.cookie] = 'question';

					var dirReader = item.createReader();
					dirReader.readEntries(function(entries) {
						for (var i = 0; i < entries.length; i++) {
							dstoreTraverseFileTree(entries[i], path + item.name + "/");
						}
					});

				}
			}
		}

		function dstoreHandleFileWriter(e) {
			var list = e.data.list;
			$.each(list, function(i, v) {
				console.log(v);
				var fname = $(v).data('path');
				var size = $(v).data('fsize');
				var dfname = fname.substring(fname.lastIndexOf('/') + 1, fname.length);
				if (!$(v).data('dir')) {

					$('#downloads').jqxWindow('show');
					$('#downloads').jqxWindow('bringToFront');
					var guid = createUUID();

					var write_obj = {//json format
						clientid : clientid,
						mesgtype : "request",
						service : "dstore",
						request : "read",
						cookie : guid,
						fname : fname,
						size : 1024,
					};
					dstore_downloader.port.postMessage({
						obj : write_obj,
						siz : size
					});
					$('#dloads').append('<div class="download_file">' + dfname + '<span class="cancel dc" data-fname="' + fname + '" data-cookie>Cancel</span></div>');
				} else {
					var data = "<strong>Directory is not supported!</strong><br><b>" + dfname + "</b> cannot be download.";

					$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>' + data + '</p>').dialog({
						resizable : false,
						height : 140,
						position : ['right', "bottom"],
						//modal : true,
						buttons : {
							OK : function() {
								$(this).dialog("close").remove();
							}
						}
					});

				}
			});
		}

		function dstoreRefresh() {
			$('#dstore_nodes').find('span[data-path="' + dstoreObj.dname + '"]').click();
		}

		function dstoreRequestHandle(node_file_li) {
			var $this = node_file_li;
			$('#location').attr('value', 'antkorp:/' + $this.attr('data-path'));
			dstoreObj.cookie = createUUID();
			dstoreObj.dname = $this.attr('data-path');
			dstoreObj.service = 'dstore';
			wssend(dstoreObj);
			maptable[dstoreObj.cookie] = "tree"//dir_json.request;
			$('#dstore_file-list').empty();
		}

		function dstoreUp() {
			var parent = dstoreObj.dname.substring(0, dstoreObj.dname.lastIndexOf('/'));
			if (parent != '')
				$('#dstore_nodes').find('span[data-path="' + parent + '"]').click();
			//console.log($('#nodes').jqxTree('selectedItem'));
		}

		function dstoreOpen(e) {
			var file = e.data.file;
			if (file.data('dir')) {
				$('#dstore_nodes').find('span[data-path="' + file.data('path') + '"]').click();
			}
		}

		function dstoreRemove(e) {
			var list = e.data.list;
			var args = [];
			$.each(list, function() {
				args.push($(this).data('fname'));
			});
			var guid = createUUID();
			var dlt_obj = {
				clientid : clientid,
				mesgtype : "request",
				service : "dstore",
				request : "remove", //mov||copy||remove||create_file||create_dir
				cookie : guid,
				source : dstoreObj.dname,
				//destination:
				srcargs : args
			}

			$("<div/>").attr('id', 'dlt_dialog').append('<p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span>HI These items will be permanently deleted and cannot be recovered. Are you sure?</p>').dialog({
				resizable : false,
				height : 140,
				modal : true,
				buttons : {
					"Delete all items" : function() {
						wssend(dlt_obj);
						maptable[dlt_obj.cookie] = 'remove';
						$(this).dialog("close");
						list.remove();
						//refresh();
					},
					Cancel : function() {
						$(this).dialog("close");
					}
				}
			});

		}

		/*
		 * ***********************************************************************************************************************************
		 *                                                        DSTORE UI BINDING CONTROLS.
		 *
		 * FIXME: dstore has to create two seperate windows for uploads and downloads.
		 * XXX:   cotnext menu for dstoer need to be modified.
		 * TODO:  dstore features are pending
		 * *************************************************************************************************************************************
		 */

		var dstoredropZone = $('#dstore_dropzone');
		dstoredropZone.bind('dragover', handleDragOver);
		dstoredropZone.bind('drop', dstoreHandleFileSelect);
		$('#dstore_inputmode').bind('change', dstoreHandleFileSelect);

		$('#dstore_nodes span.dirnode').live('click', function() {
			$node_li = $(this)
			var selectedItem = $('#dstore_nodes').jqxTree('selectedItem');
			$node_li.parent().next("ul").remove();
			dstoreRequestHandle($node_li);
		});
		/*
		 * Dstore tree is in hide mode
		 * and the tree will not be displayed for dstore.
		 * FIXME when ever you want the dstore tree remove the below line
		 */
		$('#dstore_nodes').hide();
		$('#dstore_nodes').jqxTree({
			theme : theme
		});
		$('#dstore_file-list').sortable().cnxtmenu({
			'menuid' : '#cmenu',
			items : {}
		});

		$('li.dstore-file-div').live('click', function(e) {
			e.ctrlKey ? $(this).toggleClass('selected') : $(this).parent().children('li').removeClass('selected').end().end().addClass('selected');
			var fname = $(this).data('fname');
			var typeinfo = (fname.lastIndexOf('.') > 0) ? fname.substring(fname.lastIndexOf('.') + 1, fname.length) : 'unknown';
			var size = $(this).data('fsize');
			var finfo = $(this).data('dir') ? 'Folder' : typeinfo + ' Document' + "&nbsp;&nbsp;&nbsp;" + size + ' Bytes';
		}).live('dblclick', function() {
			var $file_li = $(this);
			if ($file_li.attr('data-dir') == 'true') {
				$('#dstore_nodes').find('span[data-path="' + $file_li.data("path") + '"]').click();
				//sendreq($file_li);
			} else {
				dstoreOpen();
			}
		}).cnxtmenu({
			'menuid' : '#cmenu',
			items : {
				open : dstoreOpen,
				download : dstoreHandleFileWriter,
				info : info,
				dlt : dstoreRemove,

			}
		});

		$("#dstore_home_folder").click(function() {
			$('#dstore_home').click();
		});

		$('#dstore_gettree').click(function() {
			$('#dstore_nodes').fadeToggle();

		});
		$("#dstore_parent").click(dstoreUp);
		$("#dstore_refresh").click(dstoreRefresh);

		/*
		 * ##################################################################################################################################
		 * Konversations Script
		 * Date:31/8/2012
		 *
		 *                                                                   SERVICE: KONS
		 * #################################################################################################################################
		 */

		function handleKonsMessage(msg_obj) {
			var svr_cmds = msg_obj;
			//eval('(' + e.data + ')');
			console.log(svr_cmds);
			switch(svr_cmds.mesgtype) {

				case "event":

					if (svr_cmds.eventtype == "new_konv") {
						if (svr_cmds.konv.parent == 0) {
							//display as root post.
							var commDiv = commStructure(svr_cmds.konv.content, usersList[svr_cmds.konv.owner_uid], svr_cmds.konv.id, svr_cmds.konv.likecount, svr_cmds.konv.dislikecount);
							var commList = $('<li></li>').append(commDiv).attr('data-postid', svr_cmds.konv.id);
							var commUl = $('<ul class="comment-list"></ul>').append(commList);
							var content = $('<div class="post"></div>').append(commUl);
							$('#sharedPosts').prepend(content);

						} else {
							//display as child.
							var par = $("#sharedPosts").find('li[data-postid="' + svr_cmds.konv.parent + '"]');
							//var par = $(this).parent('div').parent('div').parent('li');
							//var color = lineColors[Math.floor(Math.random() * lineColors.length)];
							//console.log(color);
							if (par) {
								var list = par.children('ul').length ? par.children('ul') : $('<ul/>').appendTo(par);
								//.children('li').css('border-bottom-color',color);
								//var parcolor = list.data('listcolor');
								var commDiv = commStructure(svr_cmds.konv.content, usersList[svr_cmds.konv.owner_uid], svr_cmds.konv.id, svr_cmds.konv.likecount, svr_cmds.konv.dislikecount);
								var comm = $('<li></li>').append(commDiv).appendTo(list).attr('data-postid', svr_cmds.konv.id);
								//.css('border-left-color',parcolor);
							}
						}
					} else if (svr_cmds.eventtype == "update_konv") {
						var par = $("#sharedPosts").find('li[data-postid="' + svr_cmds.konv.id + '"]');

						par.children(".comment").children(".commactbar").children(".likecount").empty().append(svr_cmds.konv.likecount);
						par.children(".comment").children(".commactbar").children(".dislikecount").empty().append(svr_cmds.konv.dislikecount)
					}
					break;
				case "response":
					if (maptable[svr_cmds.cookie] == "lock") {
						if (svr_cmds.status == "success") {

						} else {

						}

					} else if (maptable[svr_cmds.cookie] == "unlock") {

					} else if (maptable[svr_cmds.cookie] == "like") {
						if (svr_cmds.status == "success") {

						} else {

						}

					} else if (maptable[svr_cmds.cookie] == 'dislike') {
						if (svr_cmds.status == "success") {

						} else {

						}

					}

					console.log("Message status: " + svr_cmds.status);
					break;

			}
		}

		function localToUTC() {
			var d = new Date();
			var d2u = d.toUTCString();
			var utl = new Date(d2u + " UTC");
			var x = document.getElementById("demo");
			x.innerHTML = d + "<br />" + d2u + "<br />" + utl.getTime();
		}

		function UTCtoLocal(utc) {
			var local;
			return local;
		}

		/*$('.searchbox').focus(function() {
		 $(this).attr('data-defaultwidth', $(this).width());
		 $(this).animate({
		 width : 250
		 }, 'slow');
		 }).blur(function() {
		 var w = $(this).attr('data-defaultwidth');
		 $(this).animate({
		 width : w
		 }, 'slow');
		 });*/

		$('#defltPostCnt').focus(function() {

			$('.post-action').fadeIn('slow', 'easeInOutElastic');
			$('#dpt-text').remove();
			$('#defltPostCnt').empty().parent().parent().css('min-height', '60px');
			$('#postcancel').fadeIn();
		})
		$('#shareSubmit').click(function() {
			$('.post-action').fadeOut('fast', 'easeInOutElastic');
			$('#postcancel').fadeOut();
			//hiding the buttons
			var commInput = $('#defltPostCnt').html();
			var date = new Date();
			if ($('#defltPostCnt').text().length) {
				konsreq(commInput, 0, "post", date.getTime());
			}
			$('#defltPostCnt').empty().append("<p id='dpt-text'>What's up...</p>").blur().parent().parent().css('min-height', '40px');
			//clear the text and replace with default message.

		});
		$('#postcancel').bind('click', function() {
			$('#postcancel').fadeOut();
			$('.post-action').fadeOut('fast', 'easeInOutElastic');
			$('#defltPostCnt').empty().append("<p id='dpt-text'>What's up...</p>").blur().parent().parent().css('min-height', '40px');
		})
		function konsreq(Input, pid, type, time) {
			var unique = createUUID();
			var shar_obj = {
				clientid : clientid,
				service : "kons",
				request : "new",
				uid : loginuserid,
				cookie : unique,
				parent : pid,
				content : Input,
				timestamp : time,
				gid : activeuser.gid

			}
			wssend(shar_obj);
			maptable[unique] = type;

		}


		$('.rep').live('click', function(e) {
			e.stopPropagation();

			var parent = $(this).parent('div').parent();
			parent.css('max-height', '800px');
			if (parent.find(".commEntry").length) {
				parent.find(".commEntry").focus();
			} else {
				//console.log($(parent + ".commEntry").length);
				var commInput = $('<p/>').addClass('commInput').attr('contenteditable', 'plaintext-only').append('<span class="dfltcmttxt">Comment</span>').focus(function() {
					$(this).css('border-color', '#04BFBF');
				});
				$('<div/>').addClass("commEntry").append(commInput).append('<button class=" btn greenbtn commpost postbtn">Post</button><button class=" btn commpostno postbtn redbtn">Discard</button>').appendTo(parent);
			}

		});

		$(".commInput").live('click', function(e) {
			$(this).children('.dfltcmttxt').remove();
		});
		$(".commpostno").live('click', function() {
			$(this).closest('div').remove();
		});

		function commStructure(commInput, owner, commentid, lc, dlc) {

			var commdata = $("<div class='original-comment'></div>").append(commInput);
			var img = $("<img height=32px width=32px/>").attr({
				'src' : owner.image_small || "css/images/user32.png",
				"align" : "left"
			});
			var upic = $('<div />').addClass('user').attr('data-uid', owner.uid).draggable({
				containment : 'document',
				appendTo : "body",
				helper : 'clone',
				revert : 'Invalid',
				zindex : 1000000
			});
			var uimg = $('<div />').addClass('uimg').append(img).appendTo(upic);
			var reply = $('<span />').addClass('rep').append("Reply");
			//$('<div class="repbox"><span class="rep">Reply</span></div>');
			var commauthr = $('<span />').addClass('commauthr').append(owner.first_name);
			var commtime;
			//= $('<span />').addClass('commtime').append('time');
			var commdelete;
			// = $('<span />').addClass('commdelete cntrl').attr('title', 'Delete');
			//.bind('click', owner, commentDelete);
			var upvote = $('<span />').addClass('commup').attr('title', 'like').bind('click', {
				author : owner,
				request : 'like',
				id : commentid
			}, commentCommands);

			var likecount = $('<span/>').addClass("likecount lc").append(lc).css({
				'color' : 'green'
			});
			var downvote = $('<span />').addClass('commdown').attr('title', 'dislike').bind('click', {
				author : owner,
				request : 'dislike',
				id : commentid
			}, commentCommands);

			var dislikecount = $('<span/>').addClass("dislikecount lc").append(dlc).css({
				'color' : 'red'
			});
			var commlock = $('<span />').addClass('commlock cntrl').attr('title', 'lock').bind('click', {
				author : owner,
				request : 'lock',
				id : commentid
			}, commentCommands);
			var communlock = $('<span />').addClass('communlock cntrl').attr('title', 'unlock').bind('click', {
				author : owner,
				request : 'unlock',
				id : commentid
			}, commentCommands);

			var collapse = $('<span />').addClass('commcollapse').attr({
				'title' : 'Collapse comments',
				"data-pos" : true
			}).bind('click', collapse_comments);
			//var expand = $('<span />').addClass('commexpand cntrl').attr('title', 'Expands comments').bind('click', expand_comments);

			var commact = $('<div class="commactbar"></div>').append(commauthr).append(commtime).append(commdelete).append(likecount).append(upvote).append(dislikecount).append(downvote).append(commlock).append(communlock).append(collapse).append(reply);

			var commDiv = $('<div/>').append(upic).append(commact).append(commdata).addClass('comment').bind('hover', function(e) {

				if (owner.uid == loginuserid) {
					$(this).children('.commactbar').children('.cntrl').show();
				} else {
					$(this).children('.commactbar').children('.cntrl').hide();
				}

			});

			//<span class="commauthr">james watson</span><span class="commtime">10:35am</span><span class="commdelete" title="Delete"></span><span class="accperm" title="customize share"></span><span class="commup" title="upvote"></span><span class="commdown" title="downvote"></span><span class="commlock locked" title="lock status"></span>

			return commDiv;
		}

		function expand_comments(e) {
			var commlist = $(this).parent().parent().siblings('ul');
			if (commlist.length) {
				commlist.slideDown();
			}
		}

		function collapse_comments(e) {
			var commlist = $(this).parent().parent().siblings('ul');
			if (commlist.length) {
				var pos = $(this).attr("data-pos");
				if (pos == "true") {
					commlist.slideUp();
					$(this).attr('data-pos', false).css("background", 'url("css/images/plus-circle.png")')
				} else {
					commlist.slideDown();
					$(this).attr('data-pos', true).css("background", 'url("css/images/minus-circle.png")')
				}
			}
		}

		function commentCommands(e) {
			var owner = e.data.author;
			var uid = owner.uid;
			var commentId = e.data.id;

			if (((e.data.request == "like") || (e.data.request == "dislike")) && (uid == loginuserid)) {
				var par = $("#sharedPosts").find('li[data-postid="' + commentId + '"]');
				var msg = $("<div/>").addClass("konvmsg").append("<p>You can't like/dislike on you post.<br/> Click on it to remove.</P>").bind('click', function() {
					$(this).remove();
				});
				setTimeout(function() {
					msg.remove();
				}, 5000)
				par.append(msg);
				return;
			}

			//$(this).parent().parent().parent().data("postId");
			var unique = createUUID();
			var commentaction_obj = {
				clientid : clientid,
				service : "kons",
				request : e.data.request,
				uid : loginuserid,
				cookie : unique,
				id : commentId
			}
			wssend(commentaction_obj);
			maptable[unique] = e.data.request;
		}


		$('.commpost').live('click', function(e) {
			$(this).closest('.comment').click();
			var commInput = $(this).siblings('.commInput').html();
			//var commDiv = commStructure(commInput);

			var parentId = $(this).parent('div').parent('div').parent('li').data('postid');

			//If($(this).siblings('.commInput').text().length) {
			konsreq(commInput, parentId, "comment");
			//}
			/*var par = $(this).parent('div').parent('div').parent('li');
			 var color = lineColors[Math.floor(Math.random() * lineColors.length)];
			 console.log(color);

			 var list = par.children('ul').length ? par.children('ul') : $('<ul/>').appendTo(par);
			 //.children('li').css('border-bottom-color',color);
			 var parcolor=list.data('listcolor');

			 var comm = $('<li></li>').append(commDiv).appendTo(list);//.css('border-left-color',parcolor);*/

			$(this).closest('div').remove();
		});

		$('.comment').live('click', function(e) {
			e.stopPropagation();
			$(this).css('max-height', '800px');
		})
		/*
		 * ##############################################################################################################################
		 * 													Service :PLANNER
		 * Date: 25/11/12
		 * ##############################################################################################################################
		 */
var today = new Date();
		$(".cal_view").attr("data-repdate", today.toDateString()).children(".caldata").hide().end().end().children(".monthview").show();

		var calender = function(date) {
			var current = date ? date : new Date();
			var month = current.getMonth();

			var now = new Date();

			var day = now.getDate();
			console.log(now);
			var year = current.getFullYear();
			tempMonth = month + 1;

			var tempDate = new Date(tempMonth + ' 1 ,' + year);
			var tempweekday = tempDate.getDay();
			var tempweekday2 = tempweekday;
			var totalFeb = 28;
			if (month == 1) {
				if (year % 4 == 0) {//if ((year % 100 != 0) && (year % 4 == 0) || (year % 400 == 0)) {
					totalFeb = 29;
				} else {
					totalFeb = 28;
				}
			}
			var totalDays = ["31", "" + totalFeb + "", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"];

			var padding = "<td class='week'>" + getWeek(year, month, tempDate.getDate()) + "</td>";
			while (tempweekday > 0) {
				if (month == 0) {
					var tmpmonth = 12;
					var yr = year - 1;
				} else {
					var tmpmonth = month;
					var yr = year;
				}
				lastmdays = totalDays[tmpmonth - 1] - tempweekday + 1;

				if (lastmdays == day && tmpmonth - 1 == now.getMonth() && yr == now.getFullYear()) {
					padding += "<td class='premonth currentday day'>" + lastmdays + "</td>";
				} else {
					padding += "<td class='premonth day'>" + lastmdays + "</td>";
				}//console.log(tempweekday);
				tempweekday--;

			}

			dayAmount = totalDays[month];
			i = "1";
			while (i <= dayAmount) {
				if (tempweekday2 > 6) {
					tempweekday2 = 0;
					padding += "</tr><tr>";
					padding += "<td class='week'>" + getWeek(year, month, i + 1) + "</td>";
				}

				if (i == day && month == now.getMonth() && year == now.getFullYear()) {
					padding += "<td class='currentday day'>" + i + "</td>";
				} else {
					padding += "<td class='currentmonth day'>" + i + "</td>";
				}

				tempweekday2++;
				i++;
			}
			var q = 0;
			while (tempweekday2 < 7) {

				//mextmdays=totalDays[month+1]-tempweekday2+1;
				q++;
				var yr = month + 1 == 12 ? year + 1 : year;

				if (q == day && month + 1 == now.getMonth() && yr == now.getFullYear()) {
					padding += "<td class='premonth currentday day'>" + q + "</td>";
				} else {
					padding += "<td class='premonth day'>" + q + "</td>";
				}
				tempweekday2++;
			}

			var monthNames = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
			//<tr class='currentmonth'><th colspan='8' class='monthdisplay'>" + monthNames[month].toUpperCase() + " " + year + "</th></tr>

			$(".monthview .calheader").attr("data-curdate", current).children("span.curmonth").html(monthNames[month]).end().children("span.curyear").html(year);
			//$(".cal_view").attr("data-repdate", current);
			var calendarTable = "<table class='calender_blocks'> ";
			calendarTable += "<tr class='weekdays'><th>CW</th>  <th>Sun</th>  <th>Mon</th> <th>Tue</th> <th>Wed</th> <th>Thu</th> <th>FRI</th> <th>Sat</th> </tr>";
			calendarTable += "<tr>";
			calendarTable += padding;
			calendarTable += "</tr></table>";
			//+ month;
			$('.caldays').html(calendarTable);
		};

		calender();

		var calhours = function() {
			var daylist = $("<table/>").addClass("calender_blocks hr_blocks").appendTo(".calhours"), time, hr;
			for (var i = 0; i < 48; i++) {
				if (i % 2 == 0) {
					time = i / 2;
					hr = $("<tr/>").append("<th>" + time + "</th><td><div></div></td>").addClass('hra');
				} else {
					time = '';
					hr = $("<tr/>").append("<th>" + time + "</th><td><div></div></td>").addClass("hrf");
				}

				daylist.append(hr);
			}
		}
		calhours();

		$(".monthview .calheader span.prevmonth").bind('click', monthChange);
		$(".monthview .calheader span.nextmonth").bind('click', monthChange);

		$(".yearview .calheader span.prevyear").bind('click', yearChange);
		$(".yearview .calheader span.nextyear").bind('click', yearChange);

		$(".dayview .calheader span.prevday").bind('click', dayChange);
		$(".dayview .calheader span.nextday").bind('click', dayChange);

		

		$("li.yeartype").bind('click', function() {
			$(this).siblings("li").removeClass("calviewtypeselect").end().addClass("calviewtypeselect");
			$(".cal_view").children(".caldata").hide();
			$(".cal_view").children(".yearview").show();
			var date = new Date($(".cal_view").attr("data-repdate"));
			yearChange();

		})
		$("li.monthtype").bind('click', function() {
			$(this).siblings("li").removeClass("calviewtypeselect").end().addClass("calviewtypeselect");
			$(".cal_view").children(".caldata").hide();
			$(".cal_view").children(".monthview").show();
			var date = new Date($(".cal_view").attr("data-repdate"));
			calender(date);

		})
		$("li.daytype").bind('click', function() {
			$(this).siblings("li").removeClass("calviewtypeselect").end().addClass("calviewtypeselect");
			$(".cal_view").children(".caldata").hide();
			$(".cal_view").children(".dayview").show();
			var date = new Date($(".cal_view").attr("data-repdate"));
			dayChange();

		})

		$(".currentyear , .day").live('click', function() {

			$(".currentyear , .day").removeClass("calselected");
			$(this).addClass("calselected");
			createNewEvent("month");

		});

		function createNewEvent(opt) {
			$('.newCalEvent').remove();

			if (opt == "month") {
				var evnt = $("<p/>").attr({
					'contenteditable' : "true",
					"plaintext-only" : "true"
				}).addClass("eventname");
				var note = $("<p><label>note:</label><div class='eventnote' contenteditable=true plaintext-only ></div></p>")
				var datefrom = $("<p><label>From:</label><input type=Date ></p>");
				var dateto = $("<p><label>To:</label><input type=Date ></p>");
				var apptype = $("<p><label>Appointment:</label><select><option>Meeting</option><option>Reminder</option></select></p>");
				var crtbtn = $("<button/>").append("create").addClass("btn").bind('click', function() {
					$('.newCalEvent').remove();
				});
				var cnlbtn = $("<button/>").append("cancel").addClass("btn redbtn").bind('click', function() {
					$('.newCalEvent').remove();
				});
				var btnbox = $("<p/>").append(crtbtn).append(cnlbtn);
				$("<div/>").addClass("newCalEvent").appendTo(".cal_view").append(evnt).append(datefrom).append(dateto).append(apptype).append(note).append(btnbox);
			} else if (opt == "day") {

				var evnt = $("<p/>").attr({
					'contenteditable' : "true",
					"plaintext-only" : "true"
				}).addClass("eventname");
				var note = $("<p><label>note:</label><div class='eventnote' contenteditable=true plaintext-only ></div></p>")
				var datefrom = $("<p><label>From:</label><input type=Date ></p>");
				var dateto = $("<p><label>To:</label><input type=Date ></p>");
				var apptype = $("<p><label>Appointment:</label><select><option>Meeting</option><option>Reminder</option></select></p>");
				var crtbtn = $("<button/>").append("create").addClass("btn").bind('click', function() {
					$('.newCalEvent').remove();
				});
				var cnlbtn = $("<button/>").append("cancel").addClass("btn redbtn").bind('click', function() {
					$('.newCalEvent').remove();
				});
				var btnbox = $("<p/>").append(crtbtn).append(cnlbtn);
				$("<div/>").addClass("newCalEvent").appendTo(".cal_view").append(evnt).append(datefrom).append(dateto).append(apptype).append(note).append(btnbox);

			}

		}

		function dayChange(e) {
			var date = new Date($(".cal_view").attr("data-repdate"));
			var month = date.getMonth();
			var year = date.getFullYear();
			var newdat = date.getDate();

			if (e) {
				var totalFeb = 28;
				if (month == 1) {
					if (year % 4 == 0) {//if ((year % 100 != 0) && (year % 4 == 0) || (year % 400 == 0)) {
						totalFeb = 29;
					} else {
						totalFeb = 28;
					}
				}
				var totalDays = ["31", "" + totalFeb + "", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"];

				newdat = $(this).attr("data-inc") == "true" ? date.getDate() + 1 : date.getDate() - 1;

				if (newdat > totalDays[month]) {
					newdat = 1;
					month += 1;
				} else if (newdat < 1) {
					month -= 1;
					newdat = totalDays[month];
				}

				if (month == 12) {

					month = 0;
					year += 1;

				} else if (month == -1) {
					month = 11;
					year -= 1;

				}
			}

			$(".dayview .calheader .curdat").html(newdat);
			var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
			var weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
			$(".dayview .calheader .curmonth").html(monthNames[month]);
			$(".dayview .calheader .curyear").html(year);

			var newformat = new Date(year, month, newdat);
			var dayname = newformat.getDay();
			$(".dayview .calheader .curday").html(weekDays[dayname]);

			$(".cal_view").attr("data-repdate", newformat);

		}

		dayChange();

		function yearChange(e) {

			var date = new Date($(".cal_view").attr("data-repdate")), newyear = date.getFullYear();

			if (e) {
				newyear = $(this).attr("data-inc") == "true" ? date.getFullYear() + 1 : date.getFullYear() - 1;
			}

			$(".yearview .calheader .curyear").html(newyear);
			$(".cal_view").attr("data-repdate", new Date(newyear, date.getMonth(), date.getDate()));

		}

		yearChange();

		function monthChange(e) {
			var now = new Date($(".cal_view").attr("data-repdate"));//$(this).parent().attr("data-curdate")

			var month = $(this).attr("data-inc") == "true" ? now.getMonth() + 1 : now.getMonth() - 1;
			var day=now.getDate();

			if (month == 12) {
				var current = new Date(now.getFullYear() + 1, 0, day);
			} else if (month == -1) {
				var current = new Date(now.getFullYear() - 1, 11, day);
			} else {
				var current = new Date(now.getFullYear(), month, day);
			}
			//console.log(current);
			calender(current);
			$(".cal_view").attr("data-repdate",current)
			
		}

		function getWeek(year, month, day) {
			//lets calc weeknumber the cruel and hard way :D
			//Find JulianDay
			month += 1;
			//use 1-12
			var a = Math.floor((14 - (month)) / 12);
			var y = year + 4800 - a;
			var m = (month) + (12 * a) - 3;
			var jd = day + Math.floor(((153 * m) + 2) / 5) + (365 * y) + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
			// (gregorian calendar)
			//var jd = (day+1)+Math.Round(((153*m)+2)/5)+(365+y) +
			//                 Math.round(y/4)-32083;    // (julian calendar)

			//now calc weeknumber according to JD
			var d4 = (jd + 31741 - (jd % 7)) % 146097 % 36524 % 1461;
			var L = Math.floor(d4 / 1460);
			var d1 = ((d4 - L) % 365) + L;
			NumberOfWeek = Math.floor(d1 / 7) + 1;
			return NumberOfWeek;
		}

		/*
		 *#################################################################################################################################
		 *  antkorp IM.
		 * 18/9/2012
		 *
		 * antkorp Voice and video chat
		 * 13/10/2012
		 *
		 *                                                                SERVICE: RTC
		 * #################################################################################################################################
		 */

		function handleRtcMessage(msg_obj) {
			console.log("message Recieved from Rtc service:");
			//console.log(msg_obj);
			var mesgtype = msg_obj.mesgtype;
			switch(mesgtype) {
				case "event":
					if (msg_obj.eventtype == "new_imsg") {
						handleNewChatMessage(msg_obj.imsg);
					} else if (msg_obj.eventtype == "text_con_invite") {

						console.log("new conference request.");
						console.log(msg_obj);
						handleTextConfInvitation(msg_obj.invite);

					} else if (msg_obj.eventtype == "text_con_invite_accept") {
						console.log("conference request accepted by invitee.");
						console.log(msg_obj);
						//handleTextConfInvitaionAccept()
					} else if (msg_obj.eventtype == "user_join_text_con") {

						userConfJoinUpdate(msg_obj.join);

					} else if (msg_obj.eventtype == "bye") {

						closePeerconnectionbyRemote();

					} else if (msg_obj.eventtype == "drop") {

						noty({
							layout : 'bottomRight',
							theme : 'default',
							type : "error",
							text : usersList[msg_obj.sndr].first_name + " declined your call. ",
						})

					} else if (msg_obj.eventtype == "candidate_event") {
						console.log("recvd candidate");
						if (!answerPending) {
							var candidate = new RTCIceCandidate({
								sdpMLineIndex : msg_obj.candobj.label,
								candidate : msg_obj.candobj.cand
							});
							peerConn.addIceCandidate(candidate);
						} else {
							console.log("Cand dropped, reason: recvd before invite accept");
						}
					}
					break;
				case 'request':
					console.log("recvng call");
					if (msg_obj.request == "call") {
						if (!peerConnCreated)
							createPeerConnection();
						onIncomingVideoCall(msg_obj);
					}
					break;

				case 'response':
					console.log("recvd pickup");
					if (msg_obj.response == "pickup") {
						peerConn.setRemoteDescription(new RTCSessionDescription(msg_obj.answer.jsepdata));
						hisname = msg_obj.answer.sndr;
					}
					break;

			}

		}

		/*
		 * **************************************************************************************************************************************
		 *                                                                VIDEO CALL USING WEBRTC.
		 * ***************************************************************************************************************************************
		 */

		sourcevid = document.getElementById("sourcevid");
		remotevid = document.getElementById("remotevid");

		$('#rtcvideo').jqxWindow({
			height : 300,
			width : 320,
			minHeight : 100,
			maxHeight : 600,
			maxWidth : 500,
			theme : 'darkblue',
			autoOpen : false,
			showCollapseButton : true,
			resizable : true
		});

		$('#rtcvideo').bind('close', function(e) {
			closePeerconnection();
		});

		function onIncomingVideoCall(msg_obj) {
			hisname = msg_obj.offer.sndr;
			var html = $("<div>You have been invited to video chat by </div>").append(usersList[hisname].first_name);
			var members = $("<div/>").addClass("chatmembers").css({
				"height" : "auto",
				"border-bottom" : "none"
			});

			var img = $('<img />').attr({
				'src' : usersList[hisname].image_small || "css/images/user32.png",
				height : 32,
				width : 32
			});

			$('<div />').addClass('uimg').attr('data-uid', hisname).append(img).appendTo(members);

			html.append(members).append("Would you like to join?");

			noty({
				layout : 'bottomRight',
				theme : 'default',
				text : html,
				buttons : [{
					addClass : 'btn btn-primary',
					text : 'Yes',
					onClick : function($noty) {

						console.log("Accepted the video chat request.")
						$noty.close();
						if (!peerConnCreated)
							createPeerConnection();
						if (!cameraOn)
							turnOnCameraAndMic();
						//hisSdp = new SessionDescription(msg_obj.offer.jsepdata);
						peerConn.setRemoteDescription(new RTCSessionDescription(msg_obj.offer.jsepdata));
						doAnswer();
					}
				}, {
					addClass : 'btn btn-danger',
					text : 'No',
					onClick : function($noty) {
						console.log("Video Chat request rejected.");
						$noty.close();

						var unique = createUUID();

						var rejectObj = {
							clientid : clientid,
							service : "rtc",
							mesgtype : "response",
							sndr : loginuserid,
							rcpt : hisname,
							response : "drop",
							cookie : unique
						}

						wssend(rejectObj);
						maptable[rejectObj.cookie] = "dropcall";

					}
				}]
			});

		}

		function onIceCandidate(event) {
			if (event.candidate) {
				var jsonText = {
					"clientid" : clientid,
					"service" : "rtc",
					"mesgtype" : "event",
					"eventtype" : "candidate_event",
					"candobj" : {
						"sndr" : loginuserid, //myname,
						"rcpt" : hisname,
						"label" : event.candidate.sdpMLineIndex,
						"cand" : event.candidate.candidate
					}
				};
				wssend(jsonText);
				console.log("Candidate sent to the peer via server");
			} else {
				console.log("End of candidates.");
			}
		}

		function setLocalAndSendMessageForCall(sessionDescription) {
			peerConn.setLocalDescription(sessionDescription);
			var call = {
				"clientid" : clientid,
				"service" : "rtc",
				"mesgtype" : "request",
				"request" : "call",
				offer : {
					"sndr" : loginuserid,
					"rcpt" : hisname,
					"jsepdata" : sessionDescription
				}
			};
			wssend(call);
			//console.log(JSON.stringify(call));
			return;
		}

		function setLocalAndSendMessageForPickup(sessionDescription) {
			peerConn.setLocalDescription(sessionDescription);
			var pickup = {
				"clientid" : clientid,
				"service" : "rtc",
				"mesgtype" : "response",
				"response" : "pickup",
				answer : {
					"sndr" : loginuserid,
					"rcpt" : hisname,
					"jsepdata" : sessionDescription
				}
			};
			wssend(pickup);
			//console.log(JSON.stringify(pickup));
			return;
		}

		function onSessionConnecting(message) {
			console.log("Session connecting ...");
			return;
		}

		function onRemoteStreamRemoved(event) {
			console.log("Remote stream removed");
			remotevid.src = "";
			return;
		}

		function onSessionOpened(message) {
			console.log("Session opened");
			return;
		}

		function onRemoteStreamAdded(event) {
			console.log("Remote stream added");
			remotevid.src = window.webkitURL.createObjectURL(event.stream);
			$('#rtcvideo').jqxWindow('show');
			$('#rtcvideo').jqxWindow({
				'title' : usersList[hisname].first_name
			})
			remotevid.style.opacity = 1;
			return;
		}

		function onPeerConnError(emesg) {
			console.log("Error on peer connection " + emesg);
			return;
		}

		function onStateChange(event) {
			console.log("Connection state changed");
			return;
		}

		function createPeerConnection() {
			if (peerConnCreated)
				return;
			var pc_config = {
				"iceServers" : [{
					"url" : "stun:stun.l.google.com:19302"
				}]
			};
			peerConn = new webkitRTCPeerConnection(pc_config);
			peerConn.onconnecting = onSessionConnecting;
			peerConn.onopen = onSessionOpened;
			peerConn.onaddstream = onRemoteStreamAdded;
			peerConn.onremovestream = onRemoteStreamRemoved;
			peerConn.onerror = onPeerConnError;
			peerConn.onstatechange = onStateChange;
			peerConn.onicecandidate = onIceCandidate;
			peerConnCreated = true;
			//console.log("Created webkitRTCPeerConnnection with config \"" + JSON.stringify(pc_config) + "\".");
			return;
		}

		function closePeerconnectionbyRemote() {
			$('#rtcvideo').jqxWindow('hide');
			peerConn.close();
			peerConn = null;
			peerConnCreated = false;
			remotevid.src = "";
			return;
		}

		function closePeerconnection() {
			var unique = createUUID();
			var obj = {
				clientid : clientid,
				service : "rtc",
				mesgtype : "request",
				request : "bye",
				cookie : unique,
				sndr : loginuserid,
				rcpt : hisname
			}
			wssend(obj);
			maptable[obj.cookie] = "callCancel";

			peerConn.close();
			peerConn = null;
			peerConnCreated = false;
			remotevid.src = "";
			return;
		}

		function turnOnCameraAndMic() {
			navigator.webkitGetUserMedia({
				video : true,
				audio : true
			}, successCallback, errorCallback);
			function successCallback(stream) {
				peerConn.addStream(stream);
				sourcevid.style.opacity = 1;
				sourcevid.src = window.webkitURL.createObjectURL(stream);
				cameraOn = true;
				if (callPending) {
					doCall();
					callPending = false;
				}
				if (answerPending) {
					doAnswer();
					answerPending = false;
				}
			}

			function errorCallback(error) {
				console.error('An error occurred: [CODE ' + error.code + ']');
			}

			return;
		}

		var mediaConstraints = {
			'has_audio' : true,
			'has_video' : true
		};
		function doCall() {
			if (cameraOn) {
				peerConn.createOffer(setLocalAndSendMessageForCall, null, mediaConstraints);
			} else
				callPending = true;
			return;
		}

		function doAnswer() {
			if (cameraOn) {
				peerConn.createAnswer(setLocalAndSendMessageForPickup, null, mediaConstraints);
			} else
				answerPending = true;
			return;
		}

		function dialUser(e) {
			//added on modification.XXX
			var user = e.data.hisid;
			var msg;
			if (e.data.status == "online") {
				msg = 'Video chat invitation sent to ' + e.data.hisname + '! </br> waiting for response...';
				if (!peerConnCreated)
					createPeerConnection();
				if (!cameraOn)
					turnOnCameraAndMic();
				hisname = user;
				doCall();
			} else {
				msg = e.data.hisname + ' is offline!. You cannot make call now...';
			}

			noty({
				layout : 'bottomRight',
				theme : 'default',
				type : 'alert',
				text : msg,
				timeout : 3000
			});

			return;
		}

		/*
		 **********************************************************************************************************************************
		 *                                                              IM With RTC Service.
		 ************************************************************************************************************************************
		 */

		function userConfJoinUpdate(join) {
			var members = $(".chatter[data-cookie=" + join.sessionid + "]").data("chatmembers");
			members.push(join.invitee);
			/*
			 * update the chatter
			 */
			$(".chatter[data-cookie=" + join.sessionid + "]").data("chatmembers", members);

			var img = $('<img />').attr({
				'src' : usersList[join.invitee].image_small || "css/images/user32.png",
				height : 32,
				width : 32
			});

			var uimg = $('<div />').addClass('uimg').attr('data-uid', join.invitee).append(img);
			var invitee_name = usersList[join.invitee].first_name;

			$(".chatmembers[data-cookie =" + join.sessionid + "]").data("chatmembers", members).append(uimg).next().append(invitee_name + " joined.");

		}

		function handleTextConfInvitation(invite) {
			var reqsender = usersList[invite.inviter].first_name;

			var html = $("<div>You have been invited to the conference by </div>").append(reqsender).append(" .<br/> Members: <br/>");
			var members = $("<div/>").addClass("chatmembers").css({
				"height" : "auto",
				"border-bottom" : "none"
			});

			for (var i = 0; i < invite.participants.length; i++) {

				var userid = invite.participants[i];

				var img = $('<img />').attr({
					'src' : usersList[userid].image_small || "css/images/user32.png",
					height : 32,
					width : 32
				});

				$('<div />').addClass('uimg').attr('data-uid', userid).append(img).appendTo(members);
			}

			html.append(members).append("<br/>Would you like to join?");

			noty({
				layout : 'bottomRight',
				theme : 'default',
				text : html,
				buttons : [{
					addClass : 'btn btn-primary',
					text : 'Yes',
					onClick : function($noty) {

						// this = button element
						// $noty = $noty element
						chatInviteResponse(invite, true, "");
						$noty.close();

					}
				}, {
					addClass : 'btn btn-danger',
					text : 'No',
					onClick : function($noty) {
						chatInviteResponse(invite, false, "")
						$noty.close();

					}
				}]
			});
		}

		function handleNewChatMessage(msg) {
			var divToUpdate = $(".chatter").filter(function() {
				return $(this).data("cookie") == msg.sessionid;
			});
			//console.log(divToUpdate);

			var name = msg.sender == loginuserid ? "me" : usersList[msg.sender].first_name;
			var sender = $("<span/>").append(name).append(" : ").addClass("sendername");
			var content = $("<span />").append(msg.content).addClass("chatdata");
			var update = $("<div />").append(sender).append(content).addClass("chatmsg");

			if (divToUpdate.length) {
				//if (!divToUpdate.hasClass('chatteractive')) {
				if (name != "me") {
					divToUpdate.effect("highlight", {
						color : "orange"
					}, 3000).addClass("unreadmsg");
				} else {
					divToUpdate.removeClass("unreadmsg");
				}
				//}

				var chatauthor = divToUpdate.data("chatauthor");
				var contentUpdate = $('#chatroom').find("div[data-chatauthor = '" + chatauthor + "']").children(".chatcontent");
				contentUpdate.append(update);
				contentUpdate.animate({
					"scrollTop" : contentUpdate[0].scrollHeight
				}, "slow");
			} else {
				var args = {
					"data" : {
						'uid' : msg.participants[0],
						"cookie" : msg.sessionid,
						"content" : update,
						"participants" : msg.participants,
					}
				}
				chatinit(args)
			}
		}

		/*$('.chatwnd').draggable().resizable({
		 maxHeight: 550,
		 maxWidth: 700,
		 minHeight: 350,
		 minWidth: 400,
		 handles: "e"
		 })*/
		$('.chatter').live('click', function() {

			$(this).siblings('li').removeClass('chatteractive').end().addClass('chatteractive');
			var chatauthor = $(this).data('chatauthor');

			$('#chatroom').children().hide().end().find("div[data-chatauthor = '" + chatauthor + "']").show();

			$('.chatip').focus();

			//$('.chatter').find('.chatteractive').removeClass('chatteractive');
			//$(this).addClass('chatteractive');
		});

		$('.chatact').bind('click', function(e) {
			e.stopPropagation();

			/*
			 * if chat chat wnd has strtched then toggle class
			 * else expand tha chat window
			 * restore if it minimized.
			 */

			$('.chatwnd').toggleClass('chatwndmin');

			if ($('.chatwnd').hasClass('chatwndmin')) {

				var prevHeight = $('.chatwnd').height();
				$('.chatwnd').data('restore', prevHeight).css('height', '30px');

				$('.chatwnd').children('.chatroom, .chatip').hide();
			} else {
				var restore = $('.chatwnd').data('restore');
				$('.chatwnd').css('height', restore);

				$('.chatwnd').children('.chatroom, .chatip').show();
			}

			$(this).toggleClass('chatactmax');
		});

		$('.chatend').live('click', function(e) {
			e.stopPropagation();
			//stops the background click.
			/*
			 * checks for acitve class.
			 * and then look at previuos element exist or not
			 * if exists then select that and remove it.
			 * else select next.
			 * finally if none tha users in chat window that will disappear.
			 *
			 */

			if ($(this).parent().hasClass('chatteractive')) {
				if ($(this).parent().prev().length) {
					$(this).parent().prev().click();
				} else {
					$(this).parent().next().click();
				}

			}

			var specwidth = $(this).parent().width();
			var chatwnd = $(".chatwnd").width();

			var userid = $(this).parent().data('chatauthor');
			$('#chatroom').find("div[data-chatauthor=" + userid + "]").remove();
			$(this).parent().remove();

			$(".chatwnd").css('width', chatwnd - specwidth);
			if (!$('.chatlist').children('li').length) {
				$(".chatwnd").hide();
			}

		})

		$('.chatip').keypress(function(e) {
			if (e.which == 13) {
				var msg = $(this).text();
				var cookie = $(".chatteractive").data("cookie");
				var members = $(".chatteractive").data("chatmembers");
				var date = new Date();
				var time = date.getTime();

				var send_imsg = {
					content : msg,
					sessionid : cookie,
					participants : members,
					timestamp : time,
				}
				var send_obj = {
					clientid : clientid,
					uid : loginuserid,
					service : "rtc",
					mesg_type : "request",
					request : "send_imsg",
					imsg : send_imsg
				}
				console.log(send_obj);
				wssend(send_obj);
				$(this).empty();
			}

		});
		/*.keydown(function(e) {
		 if (e.keyCode == 9) {
		 $(this).parent().find('.chatteractive').next().click();

		 $(this).focus();
		 }
		 })
		 */

		function chatInviteResponse(msg, response, reason) {
			var req_obj = {
				clientid : clientid,
				service : "rtc",
				mesgtype : "response",
				request : "text_con_invite_accept",
				accept : {
					sessionid : msg.sessionid,
					participants : msg.participants,
					inviter : msg.inviter,
					invitee : msg.invitee,
					accepted : response,
					reason : reason,
				}
			}

			console.log("Chat invitaion response sent.");
			wssend(req_obj);
			console.log(req_obj);

			/*
			 * start chat with new members.
			 */
			var obj = {
				data : {
					uid : msg.participants[0],
					cookie : msg.sessionid,
					participants : msg.participants
				}
			}

			chatinit(obj);
		}

		function confInvite(sid, uid, group) {
			var req_obj = {
				clientid : clientid,
				service : "rtc",
				mesgtype : "request",
				request : "text_con_invite",
				invite : {
					sessionid : sid,
					participants : group,
					inviter : loginuserid,
					invitee : uid,
					desc : "",
				}
			}

			console.log("Chat invitaion request send to :" + usersList[uid].first_name);
			wssend(req_obj);
			console.log(req_obj);
		}

		function chatinit(e) {

			var userid = e.data.uid;
			var user = usersList[userid];
			var user_status = user.status == "offline" ? user.first_name + " is now offline." : "";

			var cookie;
			if (e.data.cookie) {
				cookie = e.data.cookie;
			} else {
				cookie = createUUID();
			}

			if (!$('.chatwnd').is(":visible")) {
				$('.chatwnd').show();

				if ($('.chatwnd').hasClass('chatwndmin')) {
					$('.chatwnd').toggleClass('chatwndmin');

					var restore = $('.chatwnd').data('restore');
					$('.chatwnd').css('height', restore);

					$('.chatwnd').children('.chatroom, .chatip').show();
					$(".chatact").toggleClass('chatactmax');
				}

			}

			var members = new Array();
			members.push(loginuserid, userid);

			if (e.data.participants) {
				var joinmembers = e.data.participants;
				for (var p = 1; p < joinmembers.length; p++) {
					if ((joinmembers[p] != loginuserid) && (joinmembers[p] != userid)) {
						members.push(joinmembers[p]);
					}
				}
			}

			var checkexist = $('.chatter[data-chatauthor=' + userid + "]").length;
			var checkexistbycookie = $('.chatter[data-cookie=' + cookie + "]").length;

			if (!checkexist) {

				var dataview = $('<div/>').attr('data-chatauthor', userid).css('width', '100%').appendTo('#chatroom');
				var chatmembers = $('<div />').addClass('chatmembers').attr("data-cookie", cookie).data({
					'chatmembers' : members,
				}).appendTo(dataview).droppable({
					accept : '.user',
					drop : function(e, ui) {
						var $item = ui.draggable;
						var invitee = $item.data('uid');

						var participants = $(this).data("chatmembers");

						if ((!$(this).find("div[data-uid=" + $item.data('uid') + "]").length) && ($item.data('uid') != loginuserid)) {

							confInvite(cookie, invitee, participants);
							$(this).next().append(usersList[$item.data('uid')].first_name + " has been invited to chat.<br />");

							//$($item).clone().appendTo(this).data('uid', $item.data('uid')).removeClass("contact").unbind().find('.ustatus').remove().end().find('img').removeAttr('align');

						}
					}
				});

				var content = $('<div />').addClass('chatcontent').appendTo(dataview).append(user_status);

				for (var i = 0; i < members.length; i++) {
					if (loginuserid != members[i]) {
						var img = $('<img />').attr({
							'src' : usersList[members[i]].image_small || "css/images/user32.png",
							height : 32,
							width : 32
						});

						var uimg = $('<div />').addClass('uimg').attr('data-uid', members[i]).append(img).appendTo(chatmembers);
					}
				}

				if (e.data.content) {
					content.append(e.data.content);
				}

				var specman = $('<li class="chatter"><span class="chatname"> ' + user.first_name + '</span><span class="chatend"></span></li>').data({
					'chatmembers' : members,
				}).attr({
					'data-chatauthor' : userid,
					'data-cookie' : cookie,
				}).appendTo('.chatlist').click();

				var wndwidth = $('.chatwnd').width();

				$(".chatwnd").css('width', wndwidth + specman.width());

			} else if (!checkexistbycookie) {
				if (e.data.cookie) {
					$('.chatter[data-chatauthor=' + userid + "]").attr("data-cookie", cookie);
				}

				if (e.data.content) {
					$('#chatroom').find('div[data-chatauthor=' + userid + ']').children(".chatcontent").append(e.data.content)
				}
			}
		}

	} else {
		/*
		 * *********************************************************************************************************************************
		 *														BROWSER SUPPORT FAILURE
		 * *********************************************************************************************************************************
		 */
		$('body').hide();
		alert("We only support Google Chrome");
	}
});

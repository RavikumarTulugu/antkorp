#!/usr/bin/expect -f

# connect via scp
spawn scp js/vaultjs.js raju@helen:/var/www/html/antkorp/demo/js
#######################
expect {
-re ".*es.*o.*" {
exp_send "yes\r"
exp_continue
}
-re ".*sword.*" {
exp_send "nccw3yld\r"
}
}
interact
